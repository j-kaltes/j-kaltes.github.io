package mijn.apps.glucosedata

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pid = android.os.Process.myPid()
       // setContentView(R.layout.activity_main)
        val flater= LayoutInflater.from(this);
        val view=flater.inflate(R.layout.activity_main,null,false)
        setContentView(view)
        val text=view.findViewById<TextView>(R.id.thetext)
//        view.setText("adb logcat --pid $pid ")
//        val view = flater.inflate(R.layout.activity_main);
            text.setText("adb logcat --pid $pid")
    }
}
