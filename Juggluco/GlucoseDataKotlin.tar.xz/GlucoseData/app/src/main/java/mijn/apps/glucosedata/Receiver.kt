package mijn.apps.glucosedata

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import java.text.DateFormat
import java.util.*

class GlucoseDataReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action != ACTION) {
            Log.e(LOG_ID, "action=" + action + " != " + ACTION)
            return
        }
        val extras = intent.extras
        val name = extras!!.getString(SERIAL) //Name of sensor
        val mgdl = extras.getInt(MGDL)
        val glucose = extras.getFloat(GLUCOSECUSTOM) //Glucose value in unit in setting
        val rate = extras.getFloat(RATE) //Rate of change of glucose. See libre and dexcom label functions
        val alarm = extras.getInt(ALARM) //See showalarm.
        val time = extras.getLong(TIME) //time in mmsec
        showalarm(alarm)
        println(
            name + " glucose=" + glucose + "(mgdL=" + mgdl + ") rate=" + rate + " (libreLabel=" + librelabel(
                rate
            ) + ", Dexcomlabel=" + getdexcomlabel(rate) + ") time=" + dateformat.format(
                Date(time)
            )
        )
    }

    companion object {
        private const val LOG_ID = "Receiver"
        private const val ACTION = "glucodata.Minute"
        private const val SERIAL = "glucodata.Minute.SerialNumber"
        private const val MGDL = "glucodata.Minute.mgdl"
        private const val GLUCOSECUSTOM = "glucodata.Minute.glucose"
        private const val RATE = "glucodata.Minute.Rate"
        private const val ALARM = "glucodata.Minute.Alarm"
        private const val TIME = "glucodata.Minute.Time"
        var dateformat = DateFormat.getDateTimeInstance(DateFormat.DEFAULT, DateFormat.DEFAULT)

        fun getdexcomlabel(rate: Float): String {
            if (rate >= 3.0f) return "DoubleUp"
            if (rate >= 2.0f) return "SingleUp"
            if (rate >= 1.0f) return "FortyFiveUp"
            if (rate > -1.0f) return "Flat"
            if (rate > -2.0f) return "FortyFiveDown"
            if (rate > -3.0f) return "SingleDown"
            return if (java.lang.Float.isNaN(rate)) "" else "DoubleDown"
        }

        fun showalarm(alarm: Int) {
            if (alarm and 8 != 0) {
                print("Alarm ")
            }
            val withoutalarm = alarm and 7
            when (withoutalarm) {
                7 -> println("too low")
                6 -> println("too high")
                4 -> println("Hightest")
                5 -> println("Lowest")
            }
        }
        fun librelabel(rate: Float): String {
            if (rate <= -2.0f) return "Falling Quickly".intern()
            if (rate <= -1.0f) return "Falling".intern()
            if (rate <= 1.0f) return "Steady".intern()
            if (rate <= 2.0f) return "Rising".intern()
            return if (java.lang.Float.isNaN(rate)) "Undetermined".intern() else "Rising Quickly".intern()
        }
    }
}
