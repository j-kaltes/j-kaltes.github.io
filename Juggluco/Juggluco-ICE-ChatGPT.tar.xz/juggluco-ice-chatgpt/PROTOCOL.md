# Read-only ICE record protocol, version 1

This channel runs over a dedicated libjuice connection. It is independent of
Juggluco's existing mirror channel. Its 128-bit capability key is randomly
generated for the authorized read-only session, never copied from mirror
credentials. ICE signalling exchanges addresses; requested data travels through
the selected direct ICE connection.

The cryptographic implementation uses Juggluco's bundled LibAscon: Ascon-128a
authenticated encryption with a 16-byte tag, and Ascon-Hash for key derivation.
This is the library's existing Ascon-128a algorithm, not a claim of compatibility
with a later NIST-renamed Ascon wire format. This new application protocol has
automated interoperability and fault tests, but has not had an independent
cryptographic audit.

## Packet format

All integers use network byte order; there are no native C struct layouts on
the wire. A datagram is a 64-byte header, 0–1024 ciphertext bytes, then a 16-byte
authentication tag. The entire header is authenticated associated data.

| Offset | Bytes | Meaning |
|---:|---:|---|
| 0 | 4 | ASCII `JGI1` |
| 4 | 1 | Kind: HELLO=1, CHALLENGE=2, CONFIRM=3, READY=4, DATA=5, ACK=6 |
| 5 | 1 | Sender: client=0, phone/server=1 |
| 6 | 2 | Reserved, zero |
| 8 | 16 | Fresh client connection identifier |
| 24 | 16 | Fresh server connection identifier; zero in HELLO |
| 40 | 8 | DATA sequence, or the sequence acknowledged |
| 48 | 8 | Message number |
| 56 | 4 | Zero-based fragment index |
| 60 | 4 | Whole plaintext message size |

Handshake packets have no ciphertext and all integer fields after the
identifiers are zero. ACK packets also have no ciphertext; their sequence,
message, fragment and total fields reproduce the DATA being acknowledged.

## Keys and fresh handshake

Key derivation takes the first 16 bytes of:

```
Ascon-Hash(PSK || "Juggluco-ICE-readonly-v1/" || purpose || 0x00 || context)
```

The PSK is exactly 16 bytes. Purpose is an ASCII string and context is either
empty or the fixed 32 bytes `client_id || server_id`. LibAscon's hash API
documents its secret-prefix keyed-hash use; unlike Merkle–Damgård hashes,
Ascon-Hash does not have the length-extension issue addressed by HMAC.

Handshake key purposes are `hello`, `challenge`, `confirm`, and `ready`, with
empty context. The handshake nonce is the client identifier for HELLO/CONFIRM
and the server identifier for CHALLENGE/READY. Each kind therefore uses a
separate key. A retry retransmits the exact original packet.

1. Client generates a fresh random client identifier and authenticates HELLO.
2. Server authenticates HELLO, generates its own fresh random identifier, and
   authenticates CHALLENGE containing both identifiers.
3. Client authenticates CHALLENGE, binds its connection to that server
   identifier, and authenticates CONFIRM containing both identifiers.
4. Server authenticates CONFIRM for its current fresh identifiers and responds
   with READY. The client establishes the connection after authenticating READY.

A server never replaces an established session in response to HELLO. It holds
only one pending handshake; another client identifier is ignored until that
Channel is closed and recreated. Replaying an old HELLO can solicit a fresh
challenge but an old CONFIRM cannot authenticate that new server identifier.
Duplicate CONFIRM packets cause retransmission of the original READY, allowing
recovery from a lost final handshake message.

Session key purposes are `client-data`, `server-data`, `client-ack`, and
`server-ack`, each with both identifiers as context. DATA and ACK nonces consist
of eight zero bytes followed by the big-endian 64-bit DATA sequence. Separate
direction and kind keys prevent DATA/ACK and bidirectional nonce collisions.
Sequence counters begin at one and cannot wrap; a fresh Channel is required
before exhaustion. The key and identifiers must never be restored as an old
live Channel with reset counters.

## Reliable records and resource limits

Each direction sends one 1024-byte fragment at a time and waits for its
authenticated ACK. The final fragment may be shorter. An empty message is one
zero-length DATA fragment. Message and sequence counters begin at one. The
receiver checks sequence, message, fragment, total size and exact payload
length before appending plaintext. It accepts only the next expected fragment.
An identical duplicate of the last accepted packet receives the original ACK
without delivering its plaintext again.

The receiver buffers at most one complete unread record, up to 16 MiB. It
withholds acknowledgment of another record until the application consumes the
first. Packet retry interval is 250 ms. The caller sets an overall connection
or send deadline. A failed send closes the Channel, avoiding reuse with a
partially transferred record. An idle receive timeout leaves it established.

Neither protocol framing nor crypto authorizes particular database operations.
The phone's request dispatcher separately enforces allowed read-only targets,
query limits, expiry and revocation.
