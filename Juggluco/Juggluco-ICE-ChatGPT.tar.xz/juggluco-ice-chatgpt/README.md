# Juggluco direct ICE client — initial implementation

This package implements the requested direct data path:

```
native program in the ChatGPT execution environment <-> ICE <-> Juggluco
```

The existing Juggluco HTTPS rendezvous server exchanges SDP/candidates. It does
not forward glucose, amounts or IOB. No MCP, ChatGPT plugin, OpenAI model API,
modified Codex, or TURN data relay is used. The program, transport and data
handlers are C/C++; Android uses its JVM interface for the button and app launch.

**Platform limitation:** ordinary ChatGPT's documented data-analysis environment
cannot make external network requests. Downloading these instructions cannot
change that. This implementation needs a ChatGPT execution environment that
explicitly permits native executables, signalling HTTPS and direct UDP ICE.
It is not a demonstrated one-button integration with ordinary Android ChatGPT.

OpenAI's documented restriction:
https://help.openai.com/en/articles/8437071-data-analysis-with-chatgpt

## Contents

| File/directory | Purpose |
|---|---|
| `bin/juggluco-ice` | Built Linux x86-64 client |
| `CHATGPT.md` | Instructions for the ChatGPT instance using the client |
| `src/`, `include/` | C++ client, signalling and encrypted reliable transport |
| `vendor/` | C source of libjuice and LibAscon, with licenses |
| `android/INTEGRATION.md` | Apply the Juggluco changes and configure the button |
| `android/integration.patch` | Existing native build/signalling and Java UI changes |
| `android/juggluco_data.cpp` | Read-only access to actual Juggluco data |
| `PROTOCOL.md` | Wire protocol, authentication and reliability design |
| `VALIDATION.md` | What was tested and what still requires a phone |

The archive contains no private rendezvous hostnames or live connection keys.

## Build the client on Linux

Requirements: a C++20 compiler, a C11 compiler, GNU make, pthread, and the system
libcurl development package. On Ubuntu these are provided by `build-essential`
and `libcurl4-openssl-dev`.

```sh
make -j4
make check
bin/juggluco-ice doctor
```

libjuice and LibAscon are compiled into the client. libcurl and the C/C++ system
runtime remain dynamically linked. The included binary was built on x86-64 Linux
and requires glibc 2.34+ and libstdc++ providing GLIBCXX_3.4.32. Rebuild from source
for another architecture or an incompatible C/C++ runtime.
`make clean` removes build products and the binary, not the source.

## Install the phone side

1. Copy this package directory to `Common/src/main/cpp/jgice/` in your Juggluco
   source tree.
2. Follow `android/INTEGRATION.md`, apply `android/integration.patch`, and build
   Juggluco with your normal Android toolchain.
3. Host this archive at your chosen public HTTPS URL. Static hosting is enough
   for the archive. Do not add a personal connection configuration to it.
4. Open Juggluco's Web server settings and press **Ask ChatGPT**. Enter the
   archive URL once. The button creates a temporary read-only session and shares
   instructions with ChatGPT through Android. The regular web server does not
   need to be enabled.
5. Send the shared text. For later use, long-press the button and save the private
   conversation URL. The button opens that chat and copies new connection
   instructions for the user to paste/send.

Android app launch does not grant ChatGPT native execution/network permission,
automatically submit a message, or guarantee that a particular ChatGPT app version
accepts the share intent. Those depend on the target ChatGPT environment.

## Data coverage

The read-only phone service returns continuous glucose, sensor history/scans,
entered amounts with stable numeric label IDs, the configured web-server label
categories, the independent IOB insulin categories, and IOB computed by Juggluco.
It uses the existing export functions and IOB implementation. It does not reuse
mirror credentials or expose mirror file-write commands.

One request is bounded to 31 days and 20,000 records. Historical data over longer
periods remain accessible through successive bounded requests. Truncation is
explicit; do not silently treat a prefix as a complete period. Label/category
settings are the current settings, including when analyzing historical amounts.

Each opt-in session lasts up to 30 minutes, with a timed partial wake lock so the
phone can serve requests while ChatGPT is foreground. **Stop ChatGPT access**
revokes the session and releases the wake lock. A new press creates fresh
credentials. See integration notes for lifecycle details.

The initial reliable transport sends one 1 KiB fragment per round trip. At a
100 ms round-trip time its approximate payload ceiling is 10 KiB/s; this is a
calculation, not a measured Internet speed. Prefer smaller intervals for bulk
queries. Transfers have deadlines and fail explicitly; partial data are never
reported as a complete successful response.

## Current verification boundary

The Linux client and local transport/data tests have been built and run. The
Android patch is supplied as source, not as a tested APK. The live rendezvous
server and a physical Juggluco/ChatGPT connection have not been tested. The
implementation matches the supplied signalling client, but server-side behavior
can only be confirmed against your running server.
