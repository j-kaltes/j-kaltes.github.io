# Source provenance and licensing

Application code in this package: GPL-3.0-or-later; see LICENSE.txt.

Juggluco source used for integration was the supplied ICEweb.tar, with missing
headers/dependencies resolved from j-kaltes/Juggluco commit
ff00505dabab6da5d04ad0c64108ae17e814dd54 (primary branch at retrieval).
https://github.com/j-kaltes/Juggluco

Bundled `vendor/libjuice` is the j-kaltes/libjuice submodule at
59e691fee8a1d43c850f66b6efe5d52dba49eb82. Its source and license are included.
https://github.com/j-kaltes/libjuice

Bundled `vendor/LibAscon` is Juggluco's copy of LibAscon 1.1.1, CC0-1.0.
Its source, authors and license are included. The only packaging adjustment is
removal of Juggluco's LOGGER include/call in ascon_aead_cleanup, so the library
can compile without the Android logging subsystem. This is the existing
Ascon-128a implementation, not a claim to implement a later algorithm revision.

Linux HTTPS uses the system libcurl and its configured TLS implementation.
They are dynamically linked, not bundled. Android HTTPS uses C++ sockets and
the native TLS libraries already loaded by Juggluco. Its required functions
are resolved dynamically, with chain and hostname verification. No Java
networking source or curl port is added to the Android app.
