# Validation of this initial implementation

## Completed in the build environment

- Linux x86-64 executable compiled and `doctor` executed.
- Real libjuice connections between two local peers, with the existing binary
  signalling format implemented by an in-memory fixture.
- Encrypted Channel handshake and fragmented 16,387-byte request / 4,109-byte
  response over those real local ICE connections.
- Signalling codec length/side/layout, deferred `/done`, and cancellation while
  waiting for the other peer.
- Record sizes from zero through 100,003 bytes, packet/ACK/handshake loss,
  duplicate fragments, modified authentication tags, wrong keys, replayed old
  connection packets, message bounds, backpressure, timeout and close behavior.
- Read-only data handler tests using a fixture matching the Juggluco access API:
  labels with duplicate names, numeric label IDs, separate category systems,
  carbohydrate weights, disabled/unconfigured IOB, malformed query rejection,
  interval boundaries, no data and explicit truncation.
- Incremental HTTP response parsing: split headers/body, Content-Length,
  chunked bodies/trailers, close-delimited bodies and malformed/ambiguous framing.
- Native C++ TLS provider with a local TLS fixture: trusted localhost certificate,
  rejection of an IP address missing from the certificate SAN, rejection of an
  untrusted chain, complete framed response before server close, and cancellation
  during a pending read.
- Protocol and data-handler address/undefined-behavior sanitizer runs passed.
  LeakSanitizer could not run under the container's tracing setup.
- Android launch/session bridge syntax check using Juggluco's JNI declarations.
- Integration patch dry run against retrieved Juggluco source.

Run the bundled ordinary checks with `make check`. The tests use synthetic data
and local peers; they do not contact a user's phone.

`make check-native-https` runs the extra native TLS test. It requires OpenSSL
development headers/libraries and the `openssl` command, creates a temporary
localhost test certificate in `build/tls-fixture/`, and trusts it only in the
fixture process. No test private key is shipped in the archive.

## Not yet demonstrated

- A full Android APK build with the user's configured NDK and private native
  dependencies. The host compiler cannot parse existing explicit-object
  declarations in current Juggluco headers, so the production data adapter has
  fixture-backed tests rather than a full app compile here.
- Native TLS loading and system CA access on an actual Android phone.
- Interoperation with the real, privately configured rendezvous server. Its
  supplied client protocol was inspected; the actual server was not available.
- Retrieval from a physical Juggluco installation.
- ChatGPT Android share-intent behavior, archive fetching, or live ICE execution
  in an ordinary ChatGPT conversation.

The normal libjuice host-interface enumeration returned EPERM in this execution
environment. Local tests use the supported explicit `127.0.0.1` bind address;
the production client does not use that as a workaround. The result establishes
local protocol interoperability, not external network availability.

## First device validation

After building the modified app, start a session and run the client on a machine
with permitted ICE networking using the generated connection block. Request
`/v1/metadata`, a short glucose interval, amounts for that same interval, and
`/v1/iob`. Compare the timestamps, units, labels and IOB against Juggluco. Press
Stop and confirm further requests fail. Then repeat from the intended ChatGPT
execution environment. If that environment does not permit native execution or
external ICE networking, the requested live workflow cannot proceed there.

This is a new application protocol with automated fault tests, not a claim of a
formal cryptographic audit or production deployment verification.
