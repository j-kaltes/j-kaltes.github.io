// SPDX-License-Identifier: GPL-3.0-or-later
package tk.glucodata;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Only Android view and preference glue; transport, credentials and requests are C++. */
public final class AskChatGPT {
    private AskChatGPT() {}
    private static SharedPreferences prefs(Activity activity) {
        return activity.getSharedPreferences("ask_chatgpt", Context.MODE_PRIVATE);
    }
    public static void launchOrConfigure(Activity activity) {
        SharedPreferences p = prefs(activity);
        String archive = p.getString("archive_url", "");
        if (archive.isEmpty()) configure(activity);
        else launch(activity, archive, p.getString("chat_url", ""));
    }
    private static void launch(Activity activity, String archive, String chat) {
        String error = Natives.askChatGPT(activity, archive, chat);
        if (error != null) Toast.makeText(activity, error, Toast.LENGTH_LONG).show();
        else if (!chat.isEmpty()) Toast.makeText(activity,
                "Paste the new connection instructions into this chat and send them.",
                Toast.LENGTH_LONG).show();
    }
    public static void stop(Activity activity) {
        Natives.stopAskChatGPT();
        Toast.makeText(activity, "ChatGPT data access stopped", Toast.LENGTH_SHORT).show();
    }
    public static void configure(Activity activity) {
        SharedPreferences p = prefs(activity);
        LinearLayout form = new LinearLayout(activity);
        form.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * activity.getResources().getDisplayMetrics().density);
        form.setPadding(pad, pad, pad, pad);
        TextView details = new TextView(activity);
        details.setText("ChatGPT can read glucose, entered amounts, categories and IOB during a 30-minute session. "
                + "This keeps the phone awake until Stop or expiry. Each press creates a new private connection.\n\n"
                + "Publish the supplied client archive at an HTTPS URL and enter it below. "
                + "The first time, send the shared instructions to ChatGPT. Later, save the private conversation URL "
                + "(https://chatgpt.com/c/...), and paste the new instructions when that chat opens.\n\n"
                + Natives.askChatGPTStatus());
        form.addView(details);
        EditText archive = new EditText(activity);
        archive.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        archive.setHint("Client archive HTTPS URL");
        archive.setText(p.getString("archive_url", ""));
        form.addView(archive);
        EditText chat = new EditText(activity);
        chat.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        chat.setHint("Existing ChatGPT conversation URL (optional)");
        chat.setText(p.getString("chat_url", ""));
        form.addView(chat);
        ScrollView scroll = new ScrollView(activity);
        scroll.addView(form);
        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle("Ask ChatGPT")
                .setView(scroll)
                .setPositiveButton("Ask ChatGPT", null)
                .setNeutralButton("Stop", (d, which) -> stop(activity))
                .setNegativeButton("Close", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String a = archive.getText().toString().trim();
            String c = chat.getText().toString().trim();
            String error = Natives.askChatGPT(activity, a, c);
            if (error != null) {
                Toast.makeText(activity, error, Toast.LENGTH_LONG).show();
                return;
            }
            p.edit().putString("archive_url", a).putString("chat_url", c).apply();
            if (!c.isEmpty()) Toast.makeText(activity,
                    "Paste the new connection instructions into this chat and send them.",
                    Toast.LENGTH_LONG).show();
            dialog.dismiss();
        }));
        dialog.show();
    }
}
