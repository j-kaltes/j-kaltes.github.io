# Android integration

The Linux client and the protocol, signalling, data access, credential generation,
expiry, wake lock and launch logic are C/C++. `AskChatGPT.java` is Android view and
preference glue; `Natives.java` receives three native declarations.

This integration adds **Ask ChatGPT** and **Stop ChatGPT access** to the existing
Web server settings page. Long-press **Ask ChatGPT** to edit the public archive URL
and the optional private conversation URL, or view connection status. It does not
require enabling the normal web server, adding a mirror host, or changing the web
server's password or exposure settings.

## Install into Juggluco source

Copy this package to `Common/src/main/cpp/jgice/` inside your Juggluco tree. Then,
from the root of that tree:

```sh
patch --dry-run -p1 < Common/src/main/cpp/jgice/android/integration.patch
patch -p1 < Common/src/main/cpp/jgice/android/integration.patch
```

The patch was made against the supplied/retrieved Juggluco source. Inspect a failed
hunk if your working tree has changed; do not force it over unrelated changes. It
adds the Java view file itself, so no separate Java copy is needed. It adds an
Android-mobile-only CMake include after `add_subdirectory(libjuice)` and exports
two small signalling-selection functions from the existing `ICE.cpp`.

`integration.cmake` compiles the shared protocol and dedicated ICE peer into target
`g`. It reuses that target's existing libjuice and LibAscon code and keeps the
app's current C++ standard selection (the shared core requires at least C++20). Android HTTPS is
implemented by `native_https.cpp` with C++ sockets and the TLS library that
Juggluco already loads. It verifies the certificate chain and signalling hostname.
There is no Java networking helper and no dependency on Linux libcurl in the APK.

The loaded TLS library must provide the required verification and TLS functions;
missing functions result in an error rather than insecure fallback. Wear OS builds
are excluded from this integration. The existing Juggluco
`android.permission.WAKE_LOCK` permission is used; no new manifest permission is
needed.

## Public download and first use

Publish the client archive (containing `CHATGPT.md`, the Linux program and its
sources) at an HTTPS URL, for example on the existing GitHub Pages site. Enter that
URL when first pressing **Ask ChatGPT**. No native service runs on Pages: it merely
serves the archive.

The native code generates a random 16-byte session key and an independent random
16-byte rendezvous label. It selects the signalling hostname from the existing
private `jugglucoconnect.h` host list using the same CRC32 rule as mirror setup,
and uses the existing signalling port. The private host list and the session key
are not added to the public archive. The selected hostname and current credentials
are included in the text shared privately with ChatGPT.

The peer uses the same public STUN default as the supplied Juggluco `ICE.cpp`:
`stun.l.google.com:19302`. It supplies no TURN server or relay credentials. It will
fail when direct ICE cannot connect; it never substitutes a data relay.

The initial launch uses Android `ACTION_SEND`, `text/plain`, targeting
`com.openai.chatgpt`. If that activity is unavailable, Android's share chooser is
opened. The user still needs to select a receiver and send the message. Whether a
particular ChatGPT Android version accepts a shared text prompt must be tested on
that version; there is no automatic prompt submission API here.

## Return to the same conversation

Paste the conversation's private `https://chatgpt.com/c/...` URL into the optional
field, accessible by long-pressing the button. Do not use a public shared-chat URL.
The native code copies a fresh private connection block to the clipboard and opens
the saved chat using `ACTION_VIEW`. Paste and send that block in the chat. The
program and prior instructions can remain in the existing conversation, but a
ChatGPT execution workspace may have been discarded, so it may need to download
the archive again.

Each button press ends the previous session and starts a new 30-minute session.
Reopening the same chat never revives expired credentials.

## Lifetime and shutdown

The opt-in session keeps the CPU awake with one non-reference-counted partial wake
lock, acquired with a 30-minute system timeout. **Stop ChatGPT access** cancels the
session and releases that wake lock immediately. A separate deadline worker closes
any pending ICE connection and releases the wake lock at expiry, including when no
client has connected. Normal glucose reception never acquires this wake lock.
There is no indefinite background access and no periodic reconnect alarm.

The independent server accepts a new authenticated peer after a client finishes.
The client sends an authenticated empty message to indicate normal completion. An
idle peer is closed after 120 seconds; the session can then accept another peer
until expiry. A response transfer has a 600-second timeout. Stop/expiry closes the
channel during either wait. Android's DNS resolver may take longer than a cancelled
socket operation to return; authorization is already cancelled and the wake lock
released during that delay.

## Native API

```java
public static native String askChatGPT(Activity activity,
                                      String archiveURL,
                                      String existingChatURL);
public static native void stopAskChatGPT();
public static native String askChatGPTStatus();
```

Call `askChatGPT` on the UI thread. It returns `null` if the sharing/opening activity
was launched, otherwise a user-visible error. This does not mean ChatGPT has
received the prompt or connected. `askChatGPTStatus` includes the remaining session
lifetime; it never exposes the key. The source does not log credentials.

## Validation limits

The native Android sources were syntax-checked using Juggluco's JNI declarations;
the integration patch passed a dry run. The data and shared transport checks are
described in the package validation notes. No Android SDK/NDK APK build or physical
phone/ChatGPT end-to-end test was available here. In particular, the calling
ChatGPT environment must permit running the native client, reaching the private
signalling hostname over HTTPS and sending/receiving UDP. Instructions cannot grant
network access missing from that environment.
