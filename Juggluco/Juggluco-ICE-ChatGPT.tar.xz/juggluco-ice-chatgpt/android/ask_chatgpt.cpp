// SPDX-License-Identifier: GPL-3.0-or-later
// Native opt-in, read-only peer. No mirror host is created or changed.
#include <jni.h>
#include "jgice/ice.hpp"
#include "jgice/protocol.hpp"
#include "native_https.hpp"
#include "juggluco_data.hpp"
#include <algorithm>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <memory>
#include <mutex>
#include <stdexcept>
#include <string>
#include <thread>

// Small additions to Juggluco's existing net/ICE/ICE.cpp (see integration.patch).
extern std::string jgice_signal_hostname(std::string_view label);
extern int jgice_signal_port();
namespace {
using namespace std::chrono_literals;
constexpr auto session_duration=30min;
constexpr char package_name[]="com.openai.chatgpt";
struct Jni {
    JNIEnv* e;
    void check(){if(e->ExceptionCheck()){e->ExceptionClear();throw std::runtime_error("Android operation failed");}}
    jclass cls(const char* n){auto c=e->FindClass(n);check();if(!c)throw std::runtime_error("Android class unavailable");return c;}
    jmethodID method(jclass c,const char* n,const char* sig){auto m=e->GetMethodID(c,n,sig);check();if(!m)throw std::runtime_error("Android method unavailable");return m;}
    jmethodID smethod(jclass c,const char* n,const char* sig){auto m=e->GetStaticMethodID(c,n,sig);check();if(!m)throw std::runtime_error("Android method unavailable");return m;}
    jstring str(const std::string& s){auto v=e->NewStringUTF(s.c_str());check();return v;}
    std::string text(jstring s){if(!s)return {};const char* v=e->GetStringUTFChars(s,nullptr);check();std::string out(v);e->ReleaseStringUTFChars(s,v);return out;}
};
struct Attached {
    JavaVM* vm;JNIEnv* e=nullptr;bool attach=false;
    explicit Attached(JavaVM* v):vm(v){if(vm->GetEnv(reinterpret_cast<void**>(&e),JNI_VERSION_1_6)!=JNI_OK){if(vm->AttachCurrentThread(&e,nullptr)!=JNI_OK)throw std::runtime_error("Cannot attach Android thread");attach=true;}if(e->PushLocalFrame(64)<0){if(e->ExceptionCheck())e->ExceptionClear();if(attach)vm->DetachCurrentThread();throw std::runtime_error("Cannot allocate Android JNI frame");}}
    ~Attached(){e->PopLocalFrame(nullptr);if(attach)vm->DetachCurrentThread();}
};
std::string hex(const uint8_t* p,size_t n){constexpr char digits[]="0123456789abcdef";std::string s(n*2,'0');for(size_t i=0;i<n;++i){s[2*i]=digits[p[i]>>4];s[2*i+1]=digits[p[i]&15];}return s;}
bool public_https(std::string_view s){return s.starts_with("https://")&&s.size()>8&&s.find_first_of("\r\n\t ")==std::string_view::npos&&s.find('@')==std::string_view::npos;}
bool existing_chat(std::string_view s){return s.starts_with("https://chatgpt.com/c/")&&s.size()>22&&s.find_first_of("\r\n\t ?#")==std::string_view::npos;}
struct Session: std::enable_shared_from_this<Session> {
    JavaVM* vm; jgice::IceConfig config; jgice::Key key{};
    std::atomic_bool cancelled{false};std::atomic_bool ended{false};std::mutex mutex;std::condition_variable wake;
    std::shared_ptr<jgice::IcePeer> peer;std::shared_ptr<jgice::Channel> channel;std::string state="Waiting for ChatGPT to connect";
    std::atomic<jobject> wake_lock{nullptr};const auto static duration_ms=std::chrono::duration_cast<std::chrono::milliseconds>(session_duration).count();
    const std::chrono::steady_clock::time_point deadline=std::chrono::steady_clock::now()+session_duration;
    const int64_t expires=std::chrono::duration_cast<std::chrono::seconds>((std::chrono::system_clock::now()+session_duration).time_since_epoch()).count();
    explicit Session(JavaVM* v):vm(v){}
    ~Session(){std::fill(key.begin(),key.end(),0);}
    void status(std::string s){std::lock_guard lock(mutex);state=std::move(s);}
    std::string status(){std::lock_guard lock(mutex);return state;}
    void cancel(){cancelled=true;release_wake_lock();wake.notify_all();}
    void acquire_wake_lock(Jni& j,jobject activity){
        auto context=j.cls("android/content/Context");auto power=j.e->CallObjectMethod(activity,j.method(context,"getSystemService","(Ljava/lang/String;)Ljava/lang/Object;"),j.str("power"));j.check();
        auto powerClass=j.cls("android/os/PowerManager");auto lock=j.e->CallObjectMethod(power,j.method(powerClass,"newWakeLock","(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;"),1,j.str("Juggluco:AskChatGPT"));j.check();
        auto lockClass=j.cls("android/os/PowerManager$WakeLock");j.e->CallVoidMethod(lock,j.method(lockClass,"setReferenceCounted","(Z)V"),JNI_FALSE);j.check();
        wake_lock=j.e->NewGlobalRef(lock);j.check();if(!wake_lock.load())throw std::runtime_error("Cannot retain session wake lock");
        j.e->CallVoidMethod(lock,j.method(lockClass,"acquire","(J)V"),static_cast<jlong>(duration_ms));j.check();
    }
    void release_wake_lock(){
        auto saved_lock=wake_lock.exchange(nullptr);if(!saved_lock)return;
        try{Attached attached(vm);Jni j{attached.e};auto c=j.cls("android/os/PowerManager$WakeLock");if(j.e->CallBooleanMethod(saved_lock,j.method(c,"isHeld","()Z"))){j.check();j.e->CallVoidMethod(saved_lock,j.method(c,"release","()V"));if(j.e->ExceptionCheck())j.e->ExceptionClear();}j.e->DeleteGlobalRef(saved_lock);}catch(...){}
    }
    void close_current(){
        std::shared_ptr<jgice::IcePeer> p;std::shared_ptr<jgice::Channel> c;
        {std::lock_guard lock(mutex);p=peer;c=channel;}
        if(c)c->close();
        if(p)p->close();
    }
    void run(){
        try {
            while(!cancelled.load()&&std::chrono::steady_clock::now()<deadline){
                auto p=std::make_shared<jgice::IcePeer>(config,jgice::native_https());
                std::weak_ptr<jgice::IcePeer> weak_peer=p;
                auto c=std::make_shared<jgice::Channel>(key,true,[weak_peer](const jgice::Bytes& packet){if(auto peer=weak_peer.lock())peer->send_datagram(packet);});
                std::weak_ptr<jgice::Channel> weak_channel=c;
                p->set_receive_handler([weak_channel](const uint8_t* data,size_t size){if(auto channel=weak_channel.lock())channel->on_datagram(data,size);});
                {std::lock_guard lock(mutex);peer=p;channel=c;}
                if(cancelled.load())break;
                if(p->connect()&&c->connect(30s)){
                    p->application_ready();status("ChatGPT connected; read-only data access active");
                    while(!cancelled.load()&&std::chrono::steady_clock::now()<deadline){
                        jgice::Bytes request;
                        if(!c->receive_message(request,120s))break;
                        if(request.empty())break; // Authenticated graceful end of client session.
                        if(cancelled.load()||std::chrono::steady_clock::now()>=deadline)break;
                        if(request.size()>8192){status("Rejected oversized request");break;}
                        std::string target(request.begin(),request.end());
                        auto response=jgice::handle_request(target);
                        if(cancelled.load()||std::chrono::steady_clock::now()>=deadline)break;
                        if(!c->send_message(jgice::Bytes(response.begin(),response.end()),600s))break;
                    }
                } else if(!cancelled.load()) {
                    const auto why=p->error().empty()?c->error():p->error();status("Waiting for another connection"+(why.empty()?std::string{}:" ("+why+")"));
                }
                c->close();p->close();
                {std::unique_lock lock(mutex);if(peer==p){peer.reset();channel.reset();}wake.wait_for(lock,1s,[this]{return cancelled.load();});}
            }
        }catch(const std::exception& e){status(std::string("Session failed: ")+e.what());cancelled=true;}
        release_wake_lock();close_current();
        {std::lock_guard lock(mutex);peer.reset();channel.reset();}
        std::fill(key.begin(),key.end(),0);ended=true;
        if(std::chrono::steady_clock::now()>=deadline)status("Session expired; press Ask ChatGPT for new credentials");
        else if(cancelled.load()&&status().find("Session failed:")!=0)status("Stopped");
        wake.notify_all();
    }
    void start(){
        auto self=shared_from_this();
        std::thread([self]{self->run();}).detach();
        std::thread([self]{
            {std::unique_lock lock(self->mutex);self->wake.wait_until(lock,self->deadline,[&]{return self->cancelled.load()||self->ended.load();});}
            if(!self->ended.load()){self->cancelled=true;self->release_wake_lock();self->close_current();self->wake.notify_all();}
        }).detach();
    }
    std::string prompt(const std::string& archive){
        return "Use my Juggluco data to answer my questions. Download this archive and read CHATGPT.md first:\n"+archive+
        "\nRun its C++ juggluco-ice client in your execution environment. Use the following private connection configuration (do not upload it to any website or public archive):\n```ini\nsignal_host="+config.signal_host+
        "\nsignal_port="+std::to_string(config.signal_port)+"\nlabel="+config.label+"\nkey="+hex(key.data(),key.size())+"\nstun_host="+config.stun_host+"\nstun_port="+std::to_string(config.stun_port)+"\nexpires="+std::to_string(expires)+
        "\n```\nThe session expires after 30 minutes. This authorizes read-only access to my glucose, entered amounts and label/category settings, and Juggluco's IOB calculations. Ask me what to examine if I have not asked a question. If your execution environment blocks direct ICE/UDP access, explain the actual error; do not claim to have retrieved data and do not substitute a relay server.\n";
    }
};
std::mutex session_mutex;std::shared_ptr<Session> current;
void launch(Jni& j,jobject activity,const std::string& prompt,const std::string& chat){
    auto intentClass=j.cls("android/content/Intent");jobject intent=nullptr;
    if(!chat.empty()){
        auto context=j.cls("android/content/Context");auto clipboard=j.e->CallObjectMethod(activity,j.method(context,"getSystemService","(Ljava/lang/String;)Ljava/lang/Object;"),j.str("clipboard"));j.check();
        auto clipClass=j.cls("android/content/ClipData");auto clip=j.e->CallStaticObjectMethod(clipClass,j.smethod(clipClass,"newPlainText","(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;"),j.str("Private Juggluco connection"),j.str(prompt));j.check();
        // Hide the private capability from the Android 13 clipboard preview.
        // PersistableBundle/ClipDescription extras are available from API 24.
        auto version=j.cls("android/os/Build$VERSION");
        auto sdkField=j.e->GetStaticFieldID(version,"SDK_INT","I");j.check();
        if(j.e->GetStaticIntField(version,sdkField)>=24){
            auto bundleClass=j.cls("android/os/PersistableBundle");
            auto extras=j.e->NewObject(bundleClass,j.method(bundleClass,"<init>","()V"));j.check();
            j.e->CallVoidMethod(extras,j.method(bundleClass,"putBoolean","(Ljava/lang/String;Z)V"),j.str("android.content.extra.IS_SENSITIVE"),JNI_TRUE);j.check();
            auto description=j.e->CallObjectMethod(clip,j.method(clipClass,"getDescription","()Landroid/content/ClipDescription;"));j.check();
            auto descriptionClass=j.cls("android/content/ClipDescription");
            j.e->CallVoidMethod(description,j.method(descriptionClass,"setExtras","(Landroid/os/PersistableBundle;)V"),extras);j.check();
        }
        auto clipboardClass=j.cls("android/content/ClipboardManager");j.e->CallVoidMethod(clipboard,j.method(clipboardClass,"setPrimaryClip","(Landroid/content/ClipData;)V"),clip);j.check();
        auto uriClass=j.cls("android/net/Uri");auto uri=j.e->CallStaticObjectMethod(uriClass,j.smethod(uriClass,"parse","(Ljava/lang/String;)Landroid/net/Uri;"),j.str(chat));j.check();
        intent=j.e->NewObject(intentClass,j.method(intentClass,"<init>","(Ljava/lang/String;Landroid/net/Uri;)V"),j.str("android.intent.action.VIEW"),uri);j.check();
    }else{
        intent=j.e->NewObject(intentClass,j.method(intentClass,"<init>","(Ljava/lang/String;)V"),j.str("android.intent.action.SEND"));j.check();
        j.e->CallObjectMethod(intent,j.method(intentClass,"setType","(Ljava/lang/String;)Landroid/content/Intent;"),j.str("text/plain"));j.check();
        j.e->CallObjectMethod(intent,j.method(intentClass,"putExtra","(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;"),j.str("android.intent.extra.TEXT"),j.str(prompt));j.check();
    }
    j.e->CallObjectMethod(intent,j.method(intentClass,"setPackage","(Ljava/lang/String;)Landroid/content/Intent;"),j.str(package_name));j.check();
    auto activityClass=j.cls("android/app/Activity");auto start=j.method(activityClass,"startActivity","(Landroid/content/Intent;)V");j.e->CallVoidMethod(activity,start,intent);
    if(j.e->ExceptionCheck()){
        j.e->ExceptionClear();j.e->CallObjectMethod(intent,j.method(intentClass,"setPackage","(Ljava/lang/String;)Landroid/content/Intent;"),nullptr);j.check();
        if(chat.empty()){intent=j.e->CallStaticObjectMethod(intentClass,j.smethod(intentClass,"createChooser","(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;"),intent,j.str("Send private connection instructions to ChatGPT"));j.check();}
        j.e->CallVoidMethod(activity,start,intent);j.check();
    }
}
}
extern "C" JNIEXPORT jstring JNICALL Java_tk_glucodata_Natives_askChatGPT(JNIEnv* env,jclass,jobject activity,jstring archiveURL,jstring existingChatURL){
    std::shared_ptr<Session> session;
    try{Jni j{env};auto archive=j.text(archiveURL);auto chat=j.text(existingChatURL);
        if(!public_https(archive))throw std::runtime_error("Configure a public HTTPS archive URL first");
        if(!chat.empty()&&!existing_chat(chat))throw std::runtime_error("Saved chat URL must be https://chatgpt.com/c/... (not a public shared-chat link)");
        JavaVM* vm=nullptr;env->GetJavaVM(&vm);session=std::make_shared<Session>(vm);jgice::secure_random(session->key.data(),session->key.size());uint8_t label[16];jgice::secure_random(label,sizeof(label));session->config.label=hex(label,sizeof(label));
        session->config.signal_host=jgice_signal_hostname(session->config.label);auto port=jgice_signal_port();if(port<1||port>65535)throw std::runtime_error("Invalid signalling port");session->config.signal_port=static_cast<uint16_t>(port);session->config.side=0;session->config.stun_host="stun.l.google.com";session->config.stun_port=19302;
        if(session->config.signal_host.empty())throw std::runtime_error("No signalling host configured");
        auto prompt=session->prompt(archive);session->acquire_wake_lock(j,activity);
        {std::lock_guard lock(session_mutex);if(current)current->cancel();current=session;}
        session->start();launch(j,activity,prompt,chat);return nullptr;
    }catch(const std::exception& e){if(session){session->cancel();if(!session->ended.load())session->release_wake_lock();}if(env->ExceptionCheck())env->ExceptionClear();return env->NewStringUTF(e.what());}
}
extern "C" JNIEXPORT void JNICALL Java_tk_glucodata_Natives_stopAskChatGPT(JNIEnv*,jclass){std::lock_guard lock(session_mutex);if(current)current->cancel();}
extern "C" JNIEXPORT jstring JNICALL Java_tk_glucodata_Natives_askChatGPTStatus(JNIEnv* env,jclass){std::shared_ptr<Session> session;{std::lock_guard lock(session_mutex);session=current;}auto status=session?session->status():"Stopped";if(session&&!session->ended.load()){auto remaining=std::chrono::duration_cast<std::chrono::seconds>(session->deadline-std::chrono::steady_clock::now()).count();status+=" ("+std::to_string(std::max<int64_t>(0,remaining))+" seconds remaining)";}return env->NewStringUTF(status.c_str());}
