# Include after target g and its libjuice dependency exist.
# Expected package location: Common/src/main/cpp/jgice/
set(JGICE_ROOT "${CMAKE_CURRENT_LIST_DIR}/..")
target_sources(g PRIVATE
    "${CMAKE_CURRENT_SOURCE_DIR}/LibAscon/src/ascon_hash.c"
    "${JGICE_ROOT}/src/ice.cpp"
    "${JGICE_ROOT}/src/http_response.cpp"
    "${JGICE_ROOT}/src/protocol.cpp"
    "${JGICE_ROOT}/android/native_https.cpp"
    "${JGICE_ROOT}/android/ask_chatgpt.cpp"
    "${JGICE_ROOT}/android/juggluco_data.cpp")
target_include_directories(g PRIVATE "${JGICE_ROOT}/include" "${JGICE_ROOT}/android")
# Keep Juggluco's existing gnu++26 / gnu++2b selection. The shared core needs
# at least C++20; setting a lower target feature here could downgrade app flags.
# Existing g target supplies libjuice, the LibAscon AEAD/permutation sources,
# pthread/libc and zlib. Add only the missing Ascon hash translation unit above.
# No curl, OpenSSL addon or Java network helper is required on Android.
