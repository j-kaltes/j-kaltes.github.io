#pragma once

#include <string>
#include <string_view>

namespace jgice {

// Call only after the ICE session has authenticated and while Juggluco's
// settings/number/sensor stores are initialized. target is a path plus query,
// never an HTTP message. The result is one complete HTTP response.
// No request modifies records, settings, files, or the normal web server.
std::string handle_request(std::string_view target);

} // namespace jgice
