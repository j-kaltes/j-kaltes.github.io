// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "jgice/ice.hpp"

namespace jgice {
// Entirely native HTTPS. On Android uses Juggluco's openssl()/opencrypto()
// handles. Socket/TLS I/O is cancellable and deadline-bounded. getaddrinfo()
// uses the platform resolver, whose own DNS timeout cannot be interrupted.
HttpClient native_https();
}
