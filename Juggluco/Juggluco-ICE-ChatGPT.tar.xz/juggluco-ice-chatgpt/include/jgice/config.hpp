#pragma once
#include "ice.hpp"
#include <array>
#include <ctime>
namespace jgice {
struct ClientConfig {
    IceConfig ice;
    std::array<std::uint8_t,16> key{};
    std::time_t expires{};
};
ClientConfig read_config(const std::string& path);
void validate_target(std::string_view target);
}
