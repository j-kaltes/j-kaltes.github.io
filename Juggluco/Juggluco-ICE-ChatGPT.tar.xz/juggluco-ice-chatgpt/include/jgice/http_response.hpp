// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "jgice/ice.hpp"
namespace jgice {
// nullopt: more bytes needed. Throws for malformed/oversized responses, or
// incomplete responses at EOF. Stops at Content-Length/chunked completion.
std::optional<HttpResponse> parse_http_response(std::span<const std::uint8_t> raw,
                                              bool eof = false);
}
