#pragma once

#include <atomic>
#include <chrono>
#include <cstdint>
#include <functional>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <vector>

namespace jgice {

// The existing Juggluco rendezvous protocol is little-endian Agent_data:
// two int32 fields, ASCII side at byte 8, label at byte 9; sizeof(header)=12.
// Its allocation adds three unused bytes after the two NUL-terminated strings.
std::vector<std::uint8_t> encode_agent_data(unsigned side, std::string_view label,
                                           std::string_view description);
struct BackDescription {
    std::uint32_t was{};
    std::string description;
};
std::optional<BackDescription> decode_back_description(std::span<const std::uint8_t> body);

struct HttpRequest {
    std::string host;
    std::uint16_t port{};
    std::string method;
    std::string path;
    std::vector<std::uint8_t> body;
    std::chrono::milliseconds timeout{10000};
};
struct HttpResponse {
    long status{};
    std::vector<std::uint8_t> body;
    std::string error;
};
// Providers must verify HTTPS certificates and hostnames, preserve a GET body,
// support concurrent requests, and return within timeout (or sooner on cancel).
using HttpClient = std::function<HttpResponse(const HttpRequest&, const std::atomic_bool& cancel)>;
HttpResponse curl_https(const HttpRequest&, const std::atomic_bool& cancel);

struct IceConfig {
    std::string signal_host;
    std::uint16_t signal_port{6789};
    std::string label;
    unsigned side{1}; // 0: phone publishes first; 1: ChatGPT client.
    std::string stun_host;
    std::uint16_t stun_port{3478};
    std::chrono::milliseconds connect_timeout{90000};
    std::chrono::milliseconds http_timeout{10000};
    std::string bind_address; // Optional numeric local interface, chiefly for tests.
};

// One independent ICE peer. No mirror registration and no TURN relay.
// connect() is single-use. close() may cancel connect() from another thread.
// Join the connect() caller before destroying the object. The receive handler
// runs on an owned dispatcher thread, never inside a libjuice callback. It may
// send_datagram(), but must not call close() or destroy this object.
class IcePeer {
public:
    using ReceiveHandler = std::function<void(const std::uint8_t*, std::size_t)>;
    IcePeer(IceConfig config, HttpClient http);
    ~IcePeer();
    IcePeer(const IcePeer&) = delete;
    IcePeer& operator=(const IcePeer&) = delete;
    void set_receive_handler(ReceiveHandler handler); // Before connect().
    bool connect();
    bool send_datagram(std::span<const std::uint8_t> data);
    // Call only after the encrypted Channel handshake. This releases /done;
    // gathering completion alone must not remove the waiting rendezvous.
    void application_ready();
    void close();
    bool connected() const;
    std::string error() const;
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace jgice
