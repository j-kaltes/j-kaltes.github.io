// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include <array>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <vector>

namespace jgice {

using Bytes = std::vector<std::uint8_t>;
using Key = std::array<std::uint8_t, 16>;

// Uses the operating system CSPRNG and throws on failure. Available on Linux
// and Android. Random callbacks used below must provide fresh unpredictable bytes.
void secure_random(std::uint8_t* destination, std::size_t length);

// Authenticated, bounded record transport over libjuice datagrams. This does
// not implement Juggluco's mirror protocol and must use its own random key.
//
// Invoke on_datagram from the transport's receive thread. connect, send_message
// and receive_message block and therefore must run on another thread. One
// sender and one receiver may operate concurrently. All outgoing callbacks
// execute without the internal state mutex held; callbacks may be synchronous.
// Stop/join the underlying receive thread before destroying this object.
class Channel {
public:
    using SendDatagram = std::function<void(const Bytes&)>;
    using RandomBytes = std::function<void(std::uint8_t*, std::size_t)>;
    static constexpr std::size_t fragment_size = 1024;
    static constexpr std::size_t max_message_size = 16 * 1024 * 1024;
    static constexpr std::size_t max_datagram_size = 64 + fragment_size + 16;

    Channel(const Key& key, bool server, SendDatagram send,
            RandomBytes random = secure_random);
    ~Channel();
    Channel(const Channel&) = delete;
    Channel& operator=(const Channel&) = delete;

    void on_datagram(const std::uint8_t* data, std::size_t size);
    bool connect(std::chrono::milliseconds timeout = std::chrono::seconds(30));
    bool send_message(const Bytes& data,
                      std::chrono::milliseconds timeout = std::chrono::seconds(30));
    bool receive_message(Bytes& data,
                         std::chrono::milliseconds timeout = std::chrono::seconds(30));
    bool established() const;
    void close();
    std::string error() const;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace jgice
