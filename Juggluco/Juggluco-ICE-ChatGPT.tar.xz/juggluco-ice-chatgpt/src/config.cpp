// SPDX-License-Identifier: GPL-3.0-or-later
#include "jgice/config.hpp"
#include <fstream>
#include <map>
#include <charconv>
#include <stdexcept>
#include <algorithm>

namespace jgice {
static std::string trim(std::string s) {
    auto a=s.find_first_not_of(" \t\r");
    if(a==std::string::npos) return {};
    return s.substr(a,s.find_last_not_of(" \t\r")-a+1);
}
static std::uint64_t number(const std::string& value,std::uint64_t max) {
    std::uint64_t result{};
    auto [end,ec]=std::from_chars(value.data(),value.data()+value.size(),result);
    if(ec!=std::errc{} || end!=value.data()+value.size() || result>max)
        throw std::runtime_error("Invalid numeric connection setting");
    return result;
}
static void hostname(const std::string& host) {
    if(host.empty() || host.size()>253 || !std::all_of(host.begin(),host.end(),[](unsigned char c){
        return (c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='.'||c=='-';
    })) throw std::runtime_error("Invalid signalling/STUN hostname (use DNS name or IPv4)");
}
ClientConfig read_config(const std::string& path) {
    std::ifstream in(path);
    if(!in) throw std::runtime_error("Cannot open connection file");
    std::map<std::string,std::string> entries;
    std::string line;
    std::size_t size=0;
    while(std::getline(in,line)) {
        size+=line.size();
        if(size>8192) throw std::runtime_error("Connection file too large");
        line=trim(line);
        if(line.empty()||line[0]=='#') continue;
        auto p=line.find('=');
        if(p==std::string::npos) throw std::runtime_error("Expected key=value in connection file");
        auto key=trim(line.substr(0,p));
        if(!entries.emplace(key,trim(line.substr(p+1))).second)
            throw std::runtime_error("Duplicate connection setting: "+key);
    }
    for(const auto& [k,v]:entries) {
        if(k!="signal_host"&&k!="signal_port"&&k!="label"&&k!="key"&&k!="stun_host"&&k!="stun_port"&&k!="expires")
            throw std::runtime_error("Unknown connection setting: "+k);
    }
    auto need=[&](const char* k)->std::string {
        auto it=entries.find(k);
        if(it==entries.end()||it->second.empty()) throw std::runtime_error(std::string("Missing connection setting: ")+k);
        return it->second;
    };
    ClientConfig c;
    c.ice.signal_host=need("signal_host"); hostname(c.ice.signal_host);
    if(entries.contains("signal_port")) c.ice.signal_port=number(entries.at("signal_port"),65535);
    if(!c.ice.signal_port) throw std::runtime_error("Signalling port cannot be zero");
    c.ice.label=need("label");
    if(c.ice.label.size()<16||c.ice.label.size()>128||!std::all_of(c.ice.label.begin(),c.ice.label.end(),[](unsigned char x){
        return (x>='a'&&x<='z')||(x>='A'&&x<='Z')||(x>='0'&&x<='9')||x=='-'||x=='_';
    })) throw std::runtime_error("Invalid connection label");
    auto hex=need("key");
    if(hex.size()!=32) throw std::runtime_error("Connection key must be 32 hex characters");
    for(std::size_t i=0;i<c.key.size();++i) {
        unsigned int b{};
        auto [end,ec]=std::from_chars(hex.data()+2*i,hex.data()+2*i+2,b,16);
        if(ec!=std::errc{}||end!=hex.data()+2*i+2) throw std::runtime_error("Invalid hex connection key");
        c.key[i]=b;
    }
    if(entries.contains("stun_host")&&!entries.at("stun_host").empty()) {
        c.ice.stun_host=entries.at("stun_host"); hostname(c.ice.stun_host);
    }
    if(entries.contains("stun_port")) c.ice.stun_port=number(entries.at("stun_port"),65535);
    if(!c.ice.stun_port) throw std::runtime_error("STUN port cannot be zero");
    c.expires=number(need("expires"),0x7fffffffffffffffULL);
    if(c.expires<=std::time(nullptr)) throw std::runtime_error("Connection expired; press Ask ChatGPT in Juggluco for a fresh connection block");
    return c;
}
void validate_target(std::string_view target) {
    if(target.empty()||target.size()>1024||std::any_of(target.begin(),target.end(),[](unsigned char c){return c<33||c>126;}))
        throw std::runtime_error("Invalid request target");
    auto path=target.substr(0,target.find('?'));
    if(path!="/v1/metadata"&&path!="/v1/iob"&&path!="/v1/amounts"&&path!="/v1/glucose"&&path!="/v1/history"&&path!="/v1/scans")
        throw std::runtime_error("Unknown read-only route; see CHATGPT.md");
}
}
