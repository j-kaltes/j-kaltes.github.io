// SPDX-License-Identifier: GPL-3.0-or-later
#include "jgice/http_response.hpp"
#include <charconv>
#include <cctype>
#include <stdexcept>
namespace jgice {
namespace {
constexpr size_t max_response = 1024 * 1024;
std::string lower(std::string s){for(char& c:s)c=static_cast<char>(std::tolower(static_cast<unsigned char>(c)));return s;}
std::string_view trim(std::string_view s){while(!s.empty()&&(s.front()==' '||s.front()=='\t'))s.remove_prefix(1);while(!s.empty()&&(s.back()==' '||s.back()=='\t'))s.remove_suffix(1);return s;}
}
// A framed response finishes when its declared body is present, even if the
// rendezvous server has not yet closed its TLS socket. nullopt means read more.
std::optional<HttpResponse> parse_http_response(std::span<const std::uint8_t> raw, bool eof) {
    auto incomplete = [eof]() -> std::optional<HttpResponse> {
        if (eof) throw std::runtime_error("Incomplete HTTPS response");
        return std::nullopt;
    };
    std::string_view text(reinterpret_cast<const char*>(raw.data()),raw.size()); auto headend=text.find("\r\n\r\n");
    if(headend==std::string_view::npos) {
        if(raw.size()>32768)throw std::runtime_error("HTTPS response headers too large");
        return incomplete();
    }
    if(headend>32768)throw std::runtime_error("HTTPS response headers too large");
    auto firstend=text.find("\r\n"); auto first=text.substr(0,firstend);auto sp=first.find(' ');
    if(!first.starts_with("HTTP/1.")||sp==std::string_view::npos||first.size()<sp+4)throw std::runtime_error("Malformed HTTPS status");
    unsigned code=0;auto status=first.substr(sp+1,3);auto rc=std::from_chars(status.data(),status.data()+status.size(),code);
    if(rc.ec!=std::errc{}||rc.ptr!=status.data()+status.size()||code<200||code>599)throw std::runtime_error("Malformed or unsupported HTTPS status");
    bool chunked=false; size_t length=0; bool haslength=false;
    for(size_t pos=firstend+2;pos<headend;){auto end=text.find("\r\n",pos);auto line=text.substr(pos,end-pos);auto colon=line.find(':');if(colon==std::string_view::npos)throw std::runtime_error("Malformed HTTPS header");auto key=lower(std::string(line.substr(0,colon)));auto value=trim(line.substr(colon+1));
        if(key=="transfer-encoding"){if(chunked||lower(std::string(value))!="chunked")throw std::runtime_error("Unsupported HTTPS transfer encoding");chunked=true;}
        if(key=="content-length"){if(haslength)throw std::runtime_error("Duplicate content length");haslength=true;auto r=std::from_chars(value.data(),value.data()+value.size(),length);if(r.ec!=std::errc{}||r.ptr!=value.data()+value.size()||length>max_response)throw std::runtime_error("Invalid HTTPS content length");}
        pos=end+2;
    }
    if(chunked&&haslength)throw std::runtime_error("Ambiguous HTTPS framing");
    auto body=text.substr(headend+4);std::vector<uint8_t> out;
    if(chunked) {
        size_t pos=0;
        for(;;) {
            auto end=body.find("\r\n",pos);
            if(end==std::string_view::npos)return incomplete();
            auto size=body.substr(pos,end-pos);auto ext=size.find(';');
            if(ext!=std::string_view::npos)size=size.substr(0,ext);
            size_t n=0;auto r=std::from_chars(size.data(),size.data()+size.size(),n,16);
            if(r.ec!=std::errc{}||r.ptr!=size.data()+size.size()||n>max_response-out.size())throw std::runtime_error("Invalid HTTPS chunk size");
            pos=end+2;
            if(n==0) {
                // Consume the optional trailer block and its final empty line.
                for (;;) {
                    end=body.find("\r\n",pos);
                    if(end==std::string_view::npos)return incomplete();
                    if(end==pos) {
                        pos+=2;
                        if(pos!=body.size())throw std::runtime_error("Unexpected data after HTTPS body");
                        return HttpResponse{static_cast<long>(code),std::move(out),{}};
                    }
                    if(body.substr(pos,end-pos).find(':')==std::string_view::npos)throw std::runtime_error("Malformed HTTPS trailer");
                    pos=end+2;
                }
            }
            if(n>body.size()-pos||body.size()-pos-n<2)return incomplete();
            if(body.substr(pos+n,2)!="\r\n")throw std::runtime_error("Malformed HTTPS chunk");
            out.insert(out.end(),body.begin()+pos,body.begin()+pos+n);pos+=n+2;
        }
    } else {
        if(haslength) {
            if(body.size()<length)return incomplete();
            if(body.size()>length)throw std::runtime_error("Unexpected data after HTTPS body");
        } else if(code==204||code==304) {
            if(!body.empty())throw std::runtime_error("Unexpected HTTPS body");
        } else if(!eof) return incomplete();
        if(body.size()>max_response)throw std::runtime_error("HTTPS response too large");
        out.assign(body.begin(),body.end());
    }
    return HttpResponse{static_cast<long>(code),std::move(out),{}};
}
}
