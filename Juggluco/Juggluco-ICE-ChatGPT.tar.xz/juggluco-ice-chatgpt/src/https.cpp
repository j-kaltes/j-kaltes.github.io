#include "jgice/ice.hpp"
#include <curl/curl.h>
#include <algorithm>
#include <array>
#include <climits>
#include <limits>
#include <memory>
#include <mutex>

namespace jgice {
namespace {
constexpr std::size_t max_response_size = 65536;
std::once_flag curl_init;
CURLcode curl_init_result = CURLE_FAILED_INIT;
std::size_t append_body(char* ptr, std::size_t size, std::size_t nmemb, void* userdata) {
    auto& body = *static_cast<std::vector<std::uint8_t>*>(userdata);
    if (size && nmemb > max_response_size / size) return 0;
    const auto length = size * nmemb;
    if (length > max_response_size - body.size()) return 0;
    try { body.insert(body.end(), ptr, ptr + length); } catch (...) { return 0; }
    return length;
}
int progress(void* userdata, curl_off_t, curl_off_t, curl_off_t, curl_off_t) {
    return static_cast<const std::atomic_bool*>(userdata)->load() ? 1 : 0;
}
}

HttpResponse curl_https(const HttpRequest& req, const std::atomic_bool& cancel) {
    HttpResponse response;
    if (cancel.load()) return {0, {}, "HTTPS cancelled"};
    std::call_once(curl_init, [] { curl_init_result = curl_global_init(CURL_GLOBAL_DEFAULT); });
    if (curl_init_result != CURLE_OK) return {0, {}, "Unable to initialize HTTPS"};
    std::unique_ptr<CURL, decltype(&curl_easy_cleanup)> handle(curl_easy_init(), curl_easy_cleanup);
    if (!handle) return {0, {}, "Unable to initialize HTTPS request"};
    if ((req.method != "GET" && req.method != "PUT") ||
        (req.path != "/description" && req.path != "/address" && req.path != "/done"))
        return {0, {}, "Invalid signalling operation"};
    const auto url = "https://" + req.host + ":" + std::to_string(req.port) + req.path;
    std::array<char, CURL_ERROR_SIZE> detail{};
    auto* curl = handle.get();
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, req.method.c_str());
    // The original server requires the binary Agent_data body even on GET.
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, reinterpret_cast<const char*>(req.body.data()));
    curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE_LARGE, static_cast<curl_off_t>(req.body.size()));
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
    const auto timeout = static_cast<long>(std::clamp<std::int64_t>(req.timeout.count(), 1, LONG_MAX));
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT_MS, std::min(timeout, 10000L));
    curl_easy_setopt(curl, CURLOPT_TIMEOUT_MS, timeout);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, append_body);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response.body);
    curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, detail.data());
    curl_easy_setopt(curl, CURLOPT_XFERINFOFUNCTION, progress);
    curl_easy_setopt(curl, CURLOPT_XFERINFODATA, &cancel);
    curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0L);
    // Disable automatic Expect: 100-continue and avoid form content type.
    curl_slist* raw_headers = nullptr;
    raw_headers = curl_slist_append(raw_headers, "Content-Type: application/octet-stream");
    raw_headers = curl_slist_append(raw_headers, "Expect:");
    std::unique_ptr<curl_slist, decltype(&curl_slist_free_all)> headers(raw_headers, curl_slist_free_all);
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers.get());
    const auto code = curl_easy_perform(curl);
    if (code != CURLE_OK) {
        response.error = detail[0] ? detail.data() : curl_easy_strerror(code);
        response.body.clear();
        return response;
    }
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response.status);
    return response;
}
} // namespace jgice
