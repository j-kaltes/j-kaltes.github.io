#include "jgice/ice.hpp"

#include <juice/juice.h>
#include <algorithm>
#include <condition_variable>
#include <cstring>
#include <deque>
#include <limits>
#include <mutex>
#include <stdexcept>
#include <thread>
#include <utility>

namespace jgice {
namespace {
using Clock = std::chrono::steady_clock;
using namespace std::chrono_literals;
constexpr std::size_t max_signal_body = 65536;
void put32(std::uint8_t* p, std::uint32_t value) {
    for (unsigned i = 0; i < 4; ++i) p[i] = static_cast<std::uint8_t>(value >> (8 * i));
}
std::uint32_t get32(const std::uint8_t* p) {
    return std::uint32_t(p[0]) | (std::uint32_t(p[1]) << 8) |
           (std::uint32_t(p[2]) << 16) | (std::uint32_t(p[3]) << 24);
}
bool valid_host(std::string_view host) {
    return !host.empty() && host.size() <= 253 &&
        std::all_of(host.begin(), host.end(), [](unsigned char c) {
            return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
                   (c >= '0' && c <= '9') || c == '.' || c == '-';
        });
}
}

std::vector<std::uint8_t> encode_agent_data(unsigned side, std::string_view label,
                                           std::string_view description) {
    if (side > 1 || label.size() > 4096 || description.size() > max_signal_body ||
        label.find('\0') != std::string_view::npos ||
        description.find('\0') != std::string_view::npos)
        throw std::invalid_argument("Invalid rendezvous message");
    // Match Agent_data::datalen(), including its three trailing padding bytes.
    std::vector<std::uint8_t> bytes(14 + label.size() + description.size(), 0);
    put32(bytes.data(), static_cast<std::uint32_t>(label.size()));
    put32(bytes.data() + 4, static_cast<std::uint32_t>(description.size()));
    bytes[8] = static_cast<std::uint8_t>('0' + side);
    std::copy(label.begin(), label.end(), bytes.begin() + 9);
    std::copy(description.begin(), description.end(), bytes.begin() + 10 + label.size());
    return bytes;
}

std::optional<BackDescription> decode_back_description(std::span<const std::uint8_t> body) {
    if (body.size() < 4 || body.size() > max_signal_body) return std::nullopt;
    auto start = body.begin() + 4;
    auto end = std::find(start, body.end(), 0);
    // Original callers use a C string, but safely accept length-delimited bodies
    // too. The uint32 timestamp is retained although ICE itself does not use it.
    return BackDescription{get32(body.data()), std::string(start, end)};
}

struct IcePeer::Impl {
    IceConfig config;
    HttpClient http;
    ReceiveHandler receive;
    std::atomic_bool stop{false};
    std::atomic_bool is_connected{false};
    std::atomic_bool failed{false};
    std::mutex operation_mutex; // Serializes connect setup and destruction.
    std::mutex agent_mutex;
    juice_agent_t* agent{};
    mutable std::mutex mutex;
    std::condition_variable changed;
    std::deque<std::string> candidates;
    std::deque<std::vector<std::uint8_t>> datagrams;
    std::string last_error;
    std::string local_description;
    bool started{}, gathered{}, ready{};
    Clock::time_point deadline;
    std::thread publish_thread, poll_thread, dispatch_thread;

    Impl(IceConfig c, HttpClient h) : config(std::move(c)), http(std::move(h)) {}

    void fail(std::string message) {
        { std::lock_guard lock(mutex); if (last_error.empty()) last_error = std::move(message); }
        failed.store(true);
        changed.notify_all();
    }
    bool alive() const { return !stop.load() && !failed.load() && Clock::now() < deadline; }

    void pause(std::chrono::milliseconds duration) {
        std::unique_lock lock(mutex);
        changed.wait_until(lock, std::min(deadline, Clock::now() + duration),
                           [this] { return stop.load() || failed.load(); });
    }
    HttpResponse request(std::string method, std::string path, std::string_view description) {
        if (!alive()) return {};
        auto remaining = std::chrono::duration_cast<std::chrono::milliseconds>(deadline - Clock::now());
        HttpRequest req{config.signal_host, config.signal_port, std::move(method), std::move(path),
                        encode_agent_data(config.side, config.label, description),
                        std::max(1ms, std::min(config.http_timeout, remaining))};
        try {
            auto response = http(req, stop);
            if (response.body.size() > max_signal_body)
                return {0, {}, "Rendezvous response too large"};
            return response;
        } catch (const std::exception& e) {
            return {0, {}, e.what()};
        } catch (...) {
            return {0, {}, "Rendezvous transport exception"};
        }
    }
    bool remote_description(const HttpResponse& response) {
        if (response.status != 200 || response.body.size() < 24) return false;
        auto decoded = decode_back_description(response.body);
        return decoded && !decoded->description.empty() &&
            juice_set_remote_description(agent, decoded->description.c_str()) == JUICE_ERR_SUCCESS;
    }
    bool exchange_description() {
        // Preserve Juggluco's order: side 0 PUT first; side 1 GET then PUT.
        if (config.side == 1) {
            bool got = false;
            while (alive()) {
                if (remote_description(request("GET", "/description", ""))) { got = true; break; }
                pause(200ms);
            }
            if (!got) return false;
        }
        while (alive()) {
            const auto reply = request("PUT", "/description", local_description);
            if (reply.status == 200 && reply.body.size() >= 24) {
                if (config.side == 1 || remote_description(reply)) return true;
            }
            pause(200ms);
        }
        return false;
    }
    bool publish(std::string_view path, std::string_view text) {
        while (alive()) {
            auto reply = request("PUT", std::string(path), text);
            if (reply.status == 200) return true;
            if (reply.status == 400) {
                fail("Rendezvous rejected " + std::string(path));
                return false;
            }
            pause(200ms);
        }
        return false;
    }
    void publish_loop() {
        while (alive()) {
            std::string candidate;
            bool finish = false;
            {
                std::unique_lock lock(mutex);
                changed.wait_until(lock, deadline, [this] {
                    return stop.load() || failed.load() || !candidates.empty() || (gathered && ready);
                });
                if (!alive()) return;
                if (!candidates.empty()) { candidate = std::move(candidates.front()); candidates.pop_front(); }
                else finish = gathered && ready;
            }
            if (finish) {
                // /done in the existing service also releases waiting peers.
                // Never send it merely because gathering completed.
                publish("/done", local_description);
                return;
            }
            if (!candidate.empty() && !publish("/address", candidate)) return;
        }
    }
    void poll_loop() {
        while (alive()) {
            auto reply = request("GET", "/address", "");
            if (reply.status == 200) {
                if (reply.body.size() < 24) {
                    juice_set_remote_gathering_done(agent);
                    return;
                }
                auto decoded = decode_back_description(reply.body);
                if (decoded && !decoded->description.empty()) {
                    const auto result = juice_add_remote_candidate(agent, decoded->description.c_str());
                    if (result != JUICE_ERR_SUCCESS && result != JUICE_ERR_IGNORED) {
                        fail("Rendezvous returned an invalid ICE candidate");
                        return;
                    }
                    continue;
                }
            }
            pause(200ms);
        }
    }
    void dispatch_loop() {
        while (!stop.load()) {
            std::vector<std::uint8_t> bytes;
            {
                std::unique_lock lock(mutex);
                changed.wait(lock, [this] { return stop.load() || !datagrams.empty(); });
                if (stop.load()) return;
                bytes = std::move(datagrams.front()); datagrams.pop_front();
            }
            try { if (receive) receive(bytes.data(), bytes.size()); }
            catch (...) { fail("Datagram receive handler failed"); return; }
        }
    }
    static void state_callback(juice_agent_t*, juice_state_t state, void* ptr) {
        auto& self = *static_cast<Impl*>(ptr);
        self.is_connected.store(state == JUICE_STATE_CONNECTED || state == JUICE_STATE_COMPLETED);
        if (state == JUICE_STATE_FAILED) self.fail("ICE failed: no usable direct route");
        self.changed.notify_all();
    }
    static void candidate_callback(juice_agent_t*, const char* sdp, void* ptr) {
        auto& self = *static_cast<Impl*>(ptr);
        try {
            std::lock_guard lock(self.mutex);
            if (!self.stop.load() && self.candidates.size() < 256) self.candidates.emplace_back(sdp);
        } catch (...) { self.failed.store(true); }
        self.changed.notify_all();
    }
    static void gathered_callback(juice_agent_t*, void* ptr) {
        auto& self = *static_cast<Impl*>(ptr);
        { std::lock_guard lock(self.mutex); self.gathered = true; }
        self.changed.notify_all();
    }
    static void receive_callback(juice_agent_t*, const char* data, std::size_t size, void* ptr) {
        auto& self = *static_cast<Impl*>(ptr);
        if (!size || size > 4096 || self.stop.load()) return;
        try {
            std::lock_guard lock(self.mutex);
            // Bounded queue; packet loss here is recovered by Channel ARQ.
            if (self.datagrams.size() < 256)
                self.datagrams.emplace_back(reinterpret_cast<const std::uint8_t*>(data),
                                             reinterpret_cast<const std::uint8_t*>(data) + size);
        } catch (...) { self.failed.store(true); }
        self.changed.notify_all();
    }
};

IcePeer::IcePeer(IceConfig config, HttpClient http)
    : impl_(std::make_unique<Impl>(std::move(config), std::move(http))) {}
IcePeer::~IcePeer() { close(); }
void IcePeer::set_receive_handler(ReceiveHandler handler) {
    std::lock_guard operation(impl_->operation_mutex);
    if (impl_->started) throw std::logic_error("Receive handler must be installed before connect");
    impl_->receive = std::move(handler);
}
bool IcePeer::connect() {
    auto& p = *impl_;
    std::lock_guard operation(p.operation_mutex);
    if (p.started || p.stop.load()) { p.fail("ICE peer is single-use or closed"); return false; }
    p.started = true;
    if (!p.http || !valid_host(p.config.signal_host) || !p.config.signal_port ||
        p.config.side > 1 || p.config.label.size() < 16 || p.config.label.size() > 128 ||
        p.config.label.find('\0') != std::string::npos ||
        (!p.config.stun_host.empty() && !valid_host(p.config.stun_host)) ||
        p.config.connect_timeout <= 0ms || p.config.http_timeout <= 0ms) {
        p.fail("Invalid ICE configuration"); return false;
    }
    p.deadline = Clock::now() + p.config.connect_timeout;
    juice_config_t cfg{};
    cfg.concurrency_mode = JUICE_CONCURRENCY_MODE_THREAD;
    cfg.stun_server_host = p.config.stun_host.empty() ? nullptr : p.config.stun_host.c_str();
    cfg.stun_server_port = p.config.stun_port;
    cfg.bind_address = p.config.bind_address.empty() ? nullptr : p.config.bind_address.c_str();
    cfg.cb_state_changed = Impl::state_callback;
    cfg.cb_candidate = Impl::candidate_callback;
    cfg.cb_gathering_done = Impl::gathered_callback;
    cfg.cb_recv = Impl::receive_callback;
    cfg.user_ptr = &p;
    {
        std::lock_guard lock(p.agent_mutex);
        p.agent = juice_create(&cfg);
    }
    if (!p.agent) { p.fail("Unable to create ICE agent"); return false; }
    try {
        p.dispatch_thread = std::thread([&p] { p.dispatch_loop(); });
        char description[JUICE_MAX_SDP_STRING_LEN]{};
        if (juice_get_local_description(p.agent, description, sizeof(description)) != JUICE_ERR_SUCCESS) {
            p.fail("Unable to create local ICE description"); return false;
        }
        p.local_description = description;
        if (!p.exchange_description()) {
            p.fail(p.stop.load() ? "ICE cancelled" : "Rendezvous description exchange timed out"); return false;
        }
        p.publish_thread = std::thread([&p] { p.publish_loop(); });
        p.poll_thread = std::thread([&p] { p.poll_loop(); });
        if (juice_gather_candidates(p.agent) != JUICE_ERR_SUCCESS) {
            p.fail("ICE candidate gathering failed"); return false;
        }
        std::unique_lock lock(p.mutex);
        p.changed.wait_until(lock, p.deadline, [&p] {
            return p.stop.load() || p.failed.load() || p.is_connected.load();
        });
        if (!p.stop.load() && !p.failed.load() && p.is_connected.load()) return true;
        lock.unlock();
        p.fail(p.stop.load() ? "ICE cancelled" : "ICE connection timed out: no usable direct route");
        return false;
    } catch (const std::exception& e) {
        p.fail(std::string("ICE setup failed: ") + e.what()); return false;
    }
}
bool IcePeer::send_datagram(std::span<const std::uint8_t> data) {
    auto& p = *impl_;
    if (p.stop.load() || !p.is_connected.load() || data.empty() || data.size() > 4096) return false;
    std::lock_guard lock(p.agent_mutex);
    return p.agent && !p.stop.load() &&
        juice_send(p.agent, reinterpret_cast<const char*>(data.data()), data.size()) == JUICE_ERR_SUCCESS;
}
void IcePeer::application_ready() {
    auto& p = *impl_;
    if (!p.is_connected.load()) return;
    { std::lock_guard lock(p.mutex); p.ready = true; }
    p.changed.notify_all();
}
void IcePeer::close() {
    auto& p = *impl_;
    p.stop.store(true);
    p.changed.notify_all();
    std::lock_guard operation(p.operation_mutex);
    if (p.publish_thread.joinable()) p.publish_thread.join();
    if (p.poll_thread.joinable()) p.poll_thread.join();
    if (p.dispatch_thread.joinable()) p.dispatch_thread.join();
    {
        std::lock_guard lock(p.agent_mutex);
        if (p.agent) { juice_destroy(p.agent); p.agent = nullptr; }
    }
    p.is_connected.store(false);
}
bool IcePeer::connected() const { return impl_->is_connected.load() && !impl_->stop.load(); }
std::string IcePeer::error() const {
    std::lock_guard lock(impl_->mutex); return impl_->last_error;
}

} // namespace jgice
