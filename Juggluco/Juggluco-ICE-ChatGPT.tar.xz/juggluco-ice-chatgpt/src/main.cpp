// SPDX-License-Identifier: GPL-3.0-or-later
#include "jgice/config.hpp"
#include "jgice/protocol.hpp"
#include <curl/curl.h>
#include <juice/juice.h>
#include <algorithm>
#include <charconv>
#include <chrono>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <string>
#include <sys/utsname.h>

namespace {
using namespace std::chrono_literals;
void usage() {
    std::cout << "juggluco-ice 0.1\n"
        "  juggluco-ice doctor\n"
        "  juggluco-ice --config connection.conf [--body] get '/v1/metadata'\n"
        "  juggluco-ice --config connection.conf session\n\n"
        "session: write one read-only target per line; quit closes the connection.\n"
        "Results are full HTTP responses; --body is supported for get only.\n"
        "No MCP, model API, mirror writes, or TURN relay. Read CHATGPT.md first.\n";
}
void doctor() {
    utsname system{};
    uname(&system);
    std::cout << "juggluco-ice 0.1\nplatform=" << system.sysname << '/' << system.machine
              << "\nhttps=" << curl_version() << '\n'
              << "native_execution=working\n"
              << "external_network=not_tested\n"
              << "requirements=HTTPS signalling and direct UDP ICE/STUN permitted by host policy\n"
              << "ordinary_ChatGPT_data_analysis=external_network_unavailable_per_OpenAI_documentation\n"
              << "No network restrictions are changed or bypassed.\n";
}
struct Response {
    unsigned code;
    std::size_t body_offset;
};
Response validate_response(const jgice::Bytes& b) {
    std::string_view s(reinterpret_cast<const char*>(b.data()),b.size());
    auto end=s.find("\r\n\r\n");
    if(!s.starts_with("HTTP/1.1 ") || end==std::string_view::npos || end>32768 || s.size()<12)
        throw std::runtime_error("Peer returned malformed HTTP response");
    unsigned code{};
    auto rc=std::from_chars(s.data()+9,s.data()+12,code);
    if(rc.ec!=std::errc{} || rc.ptr!=s.data()+12 || code<100 || code>599)
        throw std::runtime_error("Peer returned invalid HTTP status");
    auto p=s.find("\r\nContent-Length: ");
    if(p==std::string_view::npos || p>=end) throw std::runtime_error("Peer response lacks Content-Length");
    p+=18;
    auto e=s.find("\r\n",p);
    std::size_t size{};
    auto parsed=std::from_chars(s.data()+p,s.data()+e,size);
    if(parsed.ec!=std::errc{} || parsed.ptr!=s.data()+e || size!=s.size()-end-4)
        throw std::runtime_error("Peer response is incomplete");
    return {code,end+4};
}
struct Session {
    jgice::ClientConfig config;
    jgice::IcePeer peer;
    jgice::Channel channel;
    explicit Session(jgice::ClientConfig c):config(std::move(c)),peer(config.ice,jgice::curl_https),
        channel(config.key,false,[this](const jgice::Bytes& bytes){peer.send_datagram(bytes);}) {
        peer.set_receive_handler([this](const std::uint8_t* data,std::size_t size){channel.on_datagram(data,size);});
    }
    ~Session() { channel.close(); peer.close(); }
    std::chrono::milliseconds remaining(std::chrono::milliseconds maximum) const {
        auto seconds=config.expires-std::time(nullptr);
        if(seconds<=0) throw std::runtime_error("Phone authorization expired; request a fresh connection block");
        return std::min(maximum,std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::seconds(seconds)));
    }
    void connect() {
        std::cerr << "Connecting directly to Juggluco...\n";
        if(!peer.connect()) throw std::runtime_error("ICE connection failed: "+peer.error());
        if(!channel.connect(remaining(30s))) throw std::runtime_error("Authentication failed: "+channel.error());
        peer.application_ready();
        std::cerr << "Authenticated direct ICE connection established.\n";
    }
    bool query(const std::string& target,bool body_only) {
        jgice::validate_target(target);
        if(!channel.send_message(jgice::Bytes(target.begin(),target.end()),remaining(30s)))
            throw std::runtime_error("Request send failed: "+channel.error());
        jgice::Bytes data;
        if(!channel.receive_message(data,remaining(600s)))
            throw std::runtime_error("Response receive failed: "+channel.error());
        auto response=validate_response(data);
        auto start=body_only?response.body_offset:0;
        std::cout.write(reinterpret_cast<const char*>(data.data()+start),data.size()-start);
        std::cout.flush();
        return response.code>=200 && response.code<300;
    }
    void finish() {
        if(channel.established()) channel.send_message({},2s);
    }
};
}

int main(int argc,char** argv) {
    try {
        juice_set_log_level(JUICE_LOG_LEVEL_NONE);
        if(argc==1){usage();return 2;}
        if(std::strcmp(argv[1],"--help")==0 || std::strcmp(argv[1],"--version")==0){usage();return 0;}
        if(std::strcmp(argv[1],"doctor")==0){doctor();return 0;}
        std::string config_path,command,target;
        bool body=false;
        for(int i=1;i<argc;++i) {
            std::string arg=argv[i];
            if(arg=="--config" && i+1<argc) config_path=argv[++i];
            else if(arg=="--body") body=true;
            else if(command.empty()&&(arg=="get"||arg=="session")) command=arg;
            else if(command=="get"&&target.empty()) target=arg;
            else throw std::runtime_error("Invalid arguments; use --help");
        }
        if(config_path.empty()||command.empty()||(command=="get"&&target.empty())||(command=="session"&&body))
            throw std::runtime_error("Invalid arguments; use --help");
        if(command=="get") jgice::validate_target(target);
        auto c=jgice::read_config(config_path);
        c.ice.connect_timeout=std::min(c.ice.connect_timeout,
            std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::seconds(c.expires-std::time(nullptr))));
        Session session(std::move(c));
        session.connect();
        bool ok=true;
        if(command=="get") ok=session.query(target,body);
        else {
            std::cerr << "Ready for request targets, one per line. Use quit to finish.\n";
            while(std::getline(std::cin,target)) {
                if(!target.empty()&&target.back()=='\r') target.pop_back();
                if(target=="quit") break;
                if(target.empty()) continue;
                if(target.size()>1024) throw std::runtime_error("Request target too long");
                ok=session.query(target,false)&&ok;
            }
        }
        session.finish();
        return ok?0:4;
    } catch(const std::exception& e) {
        std::cerr << "juggluco-ice: " << e.what() << '\n';
        return 1;
    }
}
