// SPDX-License-Identifier: GPL-3.0-or-later
#include "jgice/protocol.hpp"

#include <algorithm>
#include <cerrno>
#include <condition_variable>
#include <cstring>
#include <fcntl.h>
#include <limits>
#include <mutex>
#include <optional>
#include <stdexcept>
#include <unistd.h>

extern "C" {
#include "ascon.h"
}

namespace jgice {
namespace {
using Clock = std::chrono::steady_clock;
constexpr std::size_t header_size = 64;
constexpr std::size_t tag_size = 16;
constexpr auto retry_time = std::chrono::milliseconds(250);
enum class Kind : std::uint8_t { hello = 1, challenge, confirm, ready, data, ack };

void erase(void* storage, std::size_t length) {
    auto* p = static_cast<volatile std::uint8_t*>(storage);
    while (length--) *p++ = 0;
}

void put32(std::uint8_t* p, std::uint32_t n) {
    for (int i = 3; i >= 0; --i) { p[i] = std::uint8_t(n); n >>= 8; }
}
void put64(std::uint8_t* p, std::uint64_t n) {
    for (int i = 7; i >= 0; --i) { p[i] = std::uint8_t(n); n >>= 8; }
}
std::uint32_t get32(const std::uint8_t* p) {
    std::uint32_t n = 0;
    for (int i = 0; i < 4; ++i) n = (n << 8) | p[i];
    return n;
}
std::uint64_t get64(const std::uint8_t* p) {
    std::uint64_t n = 0;
    for (int i = 0; i < 8; ++i) n = (n << 8) | p[i];
    return n;
}

// LibAscon documents secret-prefix Ascon-Hash as a keyed hash. Fixed-size
// identifiers and separate ASCII purpose labels make each derivation unambiguous.
Key derive(const Key& master, const char* purpose,
           const Key* client = nullptr, const Key* server = nullptr) {
    Bytes material(master.begin(), master.end());
    const char prefix[] = "Juggluco-ICE-readonly-v1/";
    material.insert(material.end(), prefix, prefix + sizeof(prefix) - 1);
    material.insert(material.end(), purpose, purpose + std::strlen(purpose));
    material.push_back(0);
    if (client) material.insert(material.end(), client->begin(), client->end());
    if (server) material.insert(material.end(), server->begin(), server->end());
    std::array<std::uint8_t, ASCON_HASH_DIGEST_LEN> hash{};
    ascon_hash(hash.data(), material.data(), material.size());
    Key result{};
    std::copy_n(hash.begin(), result.size(), result.begin());
    erase(hash.data(), hash.size());
    erase(material.data(), material.size());
    return result;
}

struct Header {
    Kind kind{};
    bool server = false;
    Key client_id{};
    Key server_id{};
    std::uint64_t sequence = 0;
    std::uint64_t message = 0;
    std::uint32_t fragment = 0;
    std::uint32_t total = 0;
};

Bytes encode_header(const Header& h) {
    Bytes b(header_size, 0);
    std::memcpy(b.data(), "JGI1", 4);
    b[4] = static_cast<std::uint8_t>(h.kind);
    b[5] = h.server ? 1 : 0;
    std::copy(h.client_id.begin(), h.client_id.end(), b.begin() + 8);
    std::copy(h.server_id.begin(), h.server_id.end(), b.begin() + 24);
    put64(b.data() + 40, h.sequence);
    put64(b.data() + 48, h.message);
    put32(b.data() + 56, h.fragment);
    put32(b.data() + 60, h.total);
    return b;
}

bool decode_header(const std::uint8_t* p, std::size_t size, Header& h) {
    if (size < header_size + tag_size || size > Channel::max_datagram_size ||
        std::memcmp(p, "JGI1", 4) || p[4] < 1 || p[4] > 6 || p[5] > 1 ||
        p[6] || p[7]) return false;
    h.kind = static_cast<Kind>(p[4]);
    h.server = p[5] != 0;
    std::copy_n(p + 8, 16, h.client_id.begin());
    std::copy_n(p + 24, 16, h.server_id.begin());
    h.sequence = get64(p + 40);
    h.message = get64(p + 48);
    h.fragment = get32(p + 56);
    h.total = get32(p + 60);
    return true;
}

Key nonce(const Header& h) {
    switch (h.kind) {
        case Kind::hello:
        case Kind::confirm: return h.client_id;
        case Kind::challenge:
        case Kind::ready: return h.server_id;
        default: {
            Key n{};
            put64(n.data() + 8, h.sequence);
            return n;
        }
    }
}

Bytes seal(const Header& h, const Key& key, const std::uint8_t* data = nullptr,
           std::size_t size = 0) {
    Bytes b = encode_header(h);
    b.resize(header_size + size + tag_size);
    const auto n = nonce(h);
    const std::uint8_t empty = 0;
    ascon_aead128a_encrypt(b.data() + header_size,
                         b.data() + header_size + size, key.data(), n.data(),
                         b.data(), data ? data : &empty, header_size, size, tag_size);
    return b;
}

bool open_packet(const Header& h, const Key& key, const std::uint8_t* data,
                 std::size_t size, Bytes& plaintext) {
    const auto count = size - header_size - tag_size;
    plaintext.resize(std::max<std::size_t>(1, count));
    const auto n = nonce(h);
    const bool valid = ascon_aead128a_decrypt(plaintext.data(), key.data(), n.data(),
                         data, data + header_size, data + header_size + count,
                         header_size, count, tag_size);
    if (!valid) { erase(plaintext.data(), plaintext.size()); plaintext.clear(); }
    else plaintext.resize(count);
    return valid;
}

bool same_record(const Header& a, const Header& b) {
    return a.sequence == b.sequence && a.message == b.message &&
           a.fragment == b.fragment && a.total == b.total;
}

bool all_zero(const Key& id) {
    return std::all_of(id.begin(), id.end(), [](std::uint8_t v) { return v == 0; });
}
} // namespace

void secure_random(std::uint8_t* destination, std::size_t length) {
    if (!length) return;
    const int fd = ::open("/dev/urandom", O_RDONLY | O_CLOEXEC);
    if (fd < 0) throw std::runtime_error("Cannot open operating-system random source");
    std::size_t used = 0;
    while (used < length) {
        const auto n = ::read(fd, destination + used, length - used);
        if (n > 0) used += static_cast<std::size_t>(n);
        else if (n < 0 && errno == EINTR) continue;
        else {
            ::close(fd);
            erase(destination, used);
            throw std::runtime_error("Cannot read operating-system random source");
        }
    }
    ::close(fd);
}

struct Channel::Impl {
    Key master;
    const bool server;
    SendDatagram send;
    RandomBytes random;
    mutable std::mutex mutex;
    std::mutex send_mutex;
    std::mutex connect_mutex;
    std::condition_variable changed;
    bool closed = false;
    bool connected = false;
    bool started = false;
    bool challenged = false;
    bool keys_ready = false;
    std::string failure;
    Key client_id{};
    Key server_id{};
    Key hello_key, challenge_key, confirm_key, ready_key;
    Key tx_data{}, rx_data{}, tx_ack{}, rx_ack{};
    Bytes retry_packet;
    Bytes challenge_packet;
    Bytes ready_packet;
    std::uint64_t tx_sequence = 1;
    std::uint64_t tx_message = 1;
    std::uint64_t rx_sequence = 1;
    std::uint64_t rx_message = 1;
    std::uint32_t rx_fragment = 0;
    std::uint32_t rx_total = 0;
    Bytes assembling;
    std::optional<Bytes> received;
    Bytes last_received_packet;
    Bytes last_ack;
    Header waiting{};
    bool waiting_active = false;
    bool acknowledged = false;

    Impl(const Key& key, bool is_server, SendDatagram sender, RandomBytes rng)
        : master(key), server(is_server), send(std::move(sender)), random(std::move(rng)),
          hello_key(derive(key, "hello")), challenge_key(derive(key, "challenge")),
          confirm_key(derive(key, "confirm")), ready_key(derive(key, "ready")) {
        if (!send || !random) throw std::invalid_argument("Channel requires send and random callbacks");
    }

    ~Impl() {
        for (Key* k : {&master, &hello_key, &challenge_key, &confirm_key, &ready_key,
                       &tx_data, &rx_data, &tx_ack, &rx_ack}) erase(k->data(), k->size());
        erase(assembling.data(), assembling.size());
        if (received) erase(received->data(), received->size());
    }

    void fail_locked(const char* message) {
        if (failure.empty()) failure = message;
        closed = true;
        connected = false;
        changed.notify_all();
    }

    bool emit(const Bytes& packet) {
        if (packet.empty()) return true;
        try { send(packet); return true; }
        catch (...) {
            std::lock_guard<std::mutex> guard(mutex);
            fail_locked("Datagram send failed");
            return false;
        }
    }

    Header header(Kind kind) const {
        Header h;
        h.kind = kind;
        h.server = server;
        h.client_id = client_id;
        h.server_id = server_id;
        return h;
    }

    void setup_keys() {
        if (keys_ready) return;
        tx_data = derive(master, server ? "server-data" : "client-data", &client_id, &server_id);
        rx_data = derive(master, server ? "client-data" : "server-data", &client_id, &server_id);
        tx_ack = derive(master, server ? "server-ack" : "client-ack", &client_id, &server_id);
        rx_ack = derive(master, server ? "client-ack" : "server-ack", &client_id, &server_id);
        keys_ready = true;
    }

    Bytes handle_handshake(const Header& h, const std::uint8_t* data, std::size_t size) {
        if (size != header_size + tag_size || h.sequence || h.message || h.fragment || h.total)
            return {};
        const Key* key = nullptr;
        switch (h.kind) {
            case Kind::hello: if (server) key = &hello_key; break;
            case Kind::challenge: if (!server) key = &challenge_key; break;
            case Kind::confirm: if (server) key = &confirm_key; break;
            case Kind::ready: if (!server) key = &ready_key; break;
            default: return {};
        }
        Bytes plain;
        if (!key || !open_packet(h, *key, data, size, plain)) return {};
        if (h.kind == Kind::hello) {
            if (connected || !all_zero(h.server_id) || all_zero(h.client_id)) return {};
            if (started) return h.client_id == client_id ? challenge_packet : Bytes{};
            client_id = h.client_id;
            random(server_id.data(), server_id.size());
            if (all_zero(server_id)) { fail_locked("Random source returned a zero identifier"); return {}; }
            started = true;
            setup_keys();
            challenge_packet = seal(header(Kind::challenge), challenge_key);
            return challenge_packet;
        }
        if (!started || h.client_id != client_id) return {};
        if (h.kind == Kind::challenge) {
            if (connected || all_zero(h.server_id)) return {};
            if (challenged) return h.server_id == server_id ? retry_packet : Bytes{};
            server_id = h.server_id;
            challenged = true;
            setup_keys();
            retry_packet = seal(header(Kind::confirm), confirm_key);
            changed.notify_all();
            return retry_packet;
        }
        if (h.server_id != server_id) return {};
        if (h.kind == Kind::confirm) {
            if (!connected) {
                connected = true;
                ready_packet = seal(header(Kind::ready), ready_key);
                changed.notify_all();
            }
            return ready_packet;
        }
        if (h.kind == Kind::ready && challenged) {
            connected = true;
            changed.notify_all();
        }
        return {};
    }

    Bytes handle_record(const Header& h, const std::uint8_t* data, std::size_t size) {
        if (!connected || h.client_id != client_id || h.server_id != server_id ||
            !h.sequence || !h.message || h.total > max_message_size) return {};
        Bytes plain;
        if (!open_packet(h, h.kind == Kind::data ? rx_data : rx_ack, data, size, plain)) return {};
        if (h.kind == Kind::ack) {
            if (!plain.empty()) return {};
            if (waiting_active && same_record(h, waiting)) {
                acknowledged = true;
                changed.notify_all();
            }
            return {};
        }
        if (h.sequence + 1 == rx_sequence && size == last_received_packet.size() &&
            std::equal(data, data + size, last_received_packet.begin())) return last_ack;
        if (h.sequence != rx_sequence || h.message != rx_message ||
            h.fragment != rx_fragment || received) return {};
        const std::size_t offset = std::size_t(h.fragment) * fragment_size;
        if (offset > h.total || (h.total && offset == h.total)) return {};
        const auto expected = std::min<std::size_t>(fragment_size, h.total - offset);
        if (plain.size() != expected || (rx_fragment && h.total != rx_total)) return {};
        if (!rx_fragment) {
            rx_total = h.total;
            assembling.clear();
            assembling.reserve(h.total);
        }
        assembling.insert(assembling.end(), plain.begin(), plain.end());
        erase(plain.data(), plain.size());
        last_received_packet.assign(data, data + size);
        Header ack = h;
        ack.kind = Kind::ack;
        ack.server = server;
        last_ack = seal(ack, tx_ack);
        if (rx_sequence == std::numeric_limits<std::uint64_t>::max()) {
            fail_locked("Receive sequence exhausted"); return {};
        }
        ++rx_sequence;
        if (assembling.size() == h.total) {
            received.emplace(std::move(assembling));
            rx_fragment = 0;
            if (rx_message == std::numeric_limits<std::uint64_t>::max()) {
                fail_locked("Receive message counter exhausted"); return {};
            }
            ++rx_message;
            changed.notify_all();
        } else ++rx_fragment;
        return last_ack;
    }
};

Channel::Channel(const Key& key, bool server, SendDatagram send, RandomBytes random)
    : impl_(new Impl(key, server, std::move(send), std::move(random))) {}
Channel::~Channel() { close(); }

void Channel::on_datagram(const std::uint8_t* data, std::size_t size) {
    if (!data) return;
    Header h;
    if (!decode_header(data, size, h)) return;
    Bytes reply;
    {
        std::lock_guard<std::mutex> guard(impl_->mutex);
        if (impl_->closed || h.server == impl_->server) return;
        try {
            reply = static_cast<std::uint8_t>(h.kind) <= static_cast<std::uint8_t>(Kind::ready)
                ? impl_->handle_handshake(h, data, size) : impl_->handle_record(h, data, size);
        } catch (...) { impl_->fail_locked("Channel receive processing failed"); }
    }
    impl_->emit(reply);
}

bool Channel::connect(std::chrono::milliseconds timeout) {
    std::lock_guard<std::mutex> operation(impl_->connect_mutex);
    const auto deadline = Clock::now() + timeout;
    std::unique_lock<std::mutex> lock(impl_->mutex);
    if (impl_->connected) return true;
    if (impl_->closed) return false;
    if (impl_->server) {
        if (!impl_->changed.wait_until(lock, deadline, [this] { return impl_->connected || impl_->closed; }))
            impl_->fail_locked("Authenticated connection timed out");
        return impl_->connected;
    }
    if (!impl_->started) {
        try {
            impl_->random(impl_->client_id.data(), impl_->client_id.size());
            if (all_zero(impl_->client_id)) throw std::runtime_error("zero identifier");
            impl_->started = true;
            impl_->retry_packet = seal(impl_->header(Kind::hello), impl_->hello_key);
        } catch (...) { impl_->fail_locked("Cannot generate fresh connection identifier"); return false; }
    }
    while (!impl_->connected && !impl_->closed) {
        if (Clock::now() >= deadline) { impl_->fail_locked("Authenticated connection timed out"); break; }
        Bytes packet = impl_->retry_packet;
        lock.unlock();
        impl_->emit(packet);
        lock.lock();
        impl_->changed.wait_until(lock, std::min(deadline, Clock::now() + retry_time),
                                 [this] { return impl_->connected || impl_->closed; });
    }
    return impl_->connected;
}

bool Channel::send_message(const Bytes& data, std::chrono::milliseconds timeout) {
    std::lock_guard<std::mutex> operation(impl_->send_mutex);
    const auto deadline = Clock::now() + timeout;
    std::unique_lock<std::mutex> lock(impl_->mutex);
    if (data.size() > max_message_size) { impl_->fail_locked("Message exceeds 16 MiB limit"); return false; }
    if (!impl_->connected || impl_->closed) return false;
    const auto fragments = std::max<std::size_t>(1, (data.size() + fragment_size - 1) / fragment_size);
    for (std::size_t index = 0; index < fragments; ++index) {
        if (impl_->tx_sequence == std::numeric_limits<std::uint64_t>::max() ||
            impl_->tx_message == std::numeric_limits<std::uint64_t>::max()) {
            impl_->fail_locked("Send sequence exhausted"); return false;
        }
        Header h = impl_->header(Kind::data);
        h.sequence = impl_->tx_sequence++;
        h.message = impl_->tx_message;
        h.fragment = static_cast<std::uint32_t>(index);
        h.total = static_cast<std::uint32_t>(data.size());
        const auto offset = index * fragment_size;
        const auto count = std::min(fragment_size, data.size() - offset);
        const auto packet = seal(h, impl_->tx_data, count ? data.data() + offset : nullptr, count);
        impl_->waiting = h;
        impl_->waiting_active = true;
        impl_->acknowledged = false;
        while (!impl_->acknowledged && !impl_->closed) {
            if (Clock::now() >= deadline) { impl_->fail_locked("Reliable message send timed out"); break; }
            lock.unlock();
            impl_->emit(packet);
            lock.lock();
            impl_->changed.wait_until(lock, std::min(deadline, Clock::now() + retry_time),
                                     [this] { return impl_->acknowledged || impl_->closed; });
        }
        impl_->waiting_active = false;
        if (impl_->closed) return false;
    }
    ++impl_->tx_message;
    return true;
}

bool Channel::receive_message(Bytes& data, std::chrono::milliseconds timeout) {
    std::unique_lock<std::mutex> lock(impl_->mutex);
    if (!impl_->changed.wait_for(lock, timeout, [this] { return impl_->received || impl_->closed; }))
        return false; // An idle receive timeout does not discard a healthy session.
    if (!impl_->received) return false;
    data = std::move(*impl_->received);
    impl_->received.reset();
    return true;
}

bool Channel::established() const {
    std::lock_guard<std::mutex> guard(impl_->mutex);
    return impl_->connected && !impl_->closed;
}
void Channel::close() {
    if (!impl_) return;
    std::lock_guard<std::mutex> guard(impl_->mutex);
    impl_->fail_locked("Channel closed");
}
std::string Channel::error() const {
    std::lock_guard<std::mutex> guard(impl_->mutex);
    return impl_->failure;
}

} // namespace jgice
