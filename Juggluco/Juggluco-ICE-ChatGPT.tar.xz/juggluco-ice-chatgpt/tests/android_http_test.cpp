// SPDX-License-Identifier: GPL-3.0-or-later
#include "jgice/http_response.hpp"
#include <stdexcept>
#include <cassert>
#include <iostream>

static auto parse(std::string_view text, bool eof=false) {
    return jgice::parse_http_response(std::vector<uint8_t>(text.begin(),text.end()),eof);
}
static bool rejects(std::string_view text, bool eof=false) {
    try { parse(text,eof);return false; }catch(const std::runtime_error&){return true;}
}
int main() {
    const std::string fixed="HTTP/1.1 200 OK\r\nContent-Length: 3\r\n\r\nabc";
    for(size_t i=0;i<fixed.size();++i) assert(!parse(std::string_view(fixed).substr(0,i)));
    const auto f=parse(fixed);assert(f&&f->status==200&&std::string(f->body.begin(),f->body.end())=="abc");
    assert(rejects(fixed+"x"));
    assert(rejects(std::string_view(fixed).substr(0,fixed.size()-1),true));
    for(const auto& body:{"3\r\nabc\r\n0\r\n\r\n","1\r\na\r\n2;x=y\r\nbc\r\n0\r\nTest: trailer\r\n\r\n"}) {
        std::string chunked="HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n";chunked+=body;
        for(size_t i=0;i<chunked.size();++i)assert(!parse(std::string_view(chunked).substr(0,i)));
        const auto c=parse(chunked);assert(c&&std::string(c->body.begin(),c->body.end())=="abc");
        assert(rejects(chunked+"x"));
    }
    assert(rejects("HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\nContent-Length: 0\r\n\r\n"));
    assert(rejects("HTTP/1.1 200 OK\r\nContent-Length: 0\r\nContent-Length: 0\r\n\r\n"));
    assert(rejects("HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n0\r\nmalformed\r\n\r\n"));
    assert(rejects("HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n3\r\nabcxx"));
    assert(!parse("HTTP/1.1 200 OK\r\n\r\nabc"));
    assert(parse("HTTP/1.1 200 OK\r\n\r\nabc",true));
    assert(parse("HTTP/1.1 204 No Content\r\n\r\n"));
    std::cout<<"Android HTTP framing tests passed\n";
}
