#include "data_test_backend.hpp"
#include "../android/juggluco_data.hpp"
#include <cassert>
#include <cstring>
#include <iostream>

TestSettings state;
TestSettings *settings = &state;
Sensoren sensor_state;
Sensoren *sensors = &sensor_state;
std::vector<Numdata*> numdatas;
unsigned iob_calls{}, export_calls{};
uint32_t iob_at{};
double getiob(uint32_t at) { ++iob_calls; iob_at = at; return 1.25; }
std::span<char> getstream(int startpos, int, uint32_t start, uint32_t end, bool header,
                          int unit, bool, int limit, bool calibrated, bool pastvalues) {
    ++export_calls;
    assert(startpos == 0 && header && limit > 0);
    assert(start < end && (unit == 1 || unit == 2));
    assert(!pastvalues || calibrated);
    std::string data = "Sensorid\tUnixTime\tmmol/L\n";
    for (int n = 0; n < std::min(limit, 3); ++n) data += "SENSOR\t" + std::to_string(start + n) + "\t6.2\n";
    auto *buf = new char[data.size()];
    std::memcpy(buf, data.data(), data.size());
    return {buf, data.size()};
}
std::span<char> gethistory(int a,int b,uint32_t c,uint32_t d,bool e,int f,bool g,int h,bool i,bool j) {
    return getstream(a,b,c,d,e,f,g,h,i,j);
}
std::span<char> getscans(int a,int b,uint32_t c,uint32_t d,bool e,int f,bool g,int h,bool i,bool j) {
    return getstream(a,b,c,d,e,f,g,h,i,j);
}
bool has(const std::string &s, const char *find) { return s.find(find) != std::string::npos; }
std::string run(std::string_view target, unsigned code) {
    auto out = jgice::handle_request(target);
    assert(out.starts_with("HTTP/1.1 " + std::to_string(code) + " "));
    auto begin = out.find("Content-Length: ") + std::strlen("Content-Length: ");
    auto end = out.find("\r\n", begin);
    assert(std::stoul(out.substr(begin, end - begin)) == out.size() - out.find("\r\n\r\n") - 4);
    assert(has(out, "Cache-Control: no-store"));
    return out;
}
int main() {
    state.d.Nightnums[0] = {1, 1};
    state.d.Nightnums[1] = {3, 0.5};
    state.d.Nightnums[2] = {0, 0};
    auto meta = run("/v1/metadata", 200);
    assert(has(meta, "\"web_category\":\"carbohydrate\""));
    assert(has(meta, "\"carbohydrate_grams_per_value\":0.5"));
    assert(has(meta, "\"iob_insulin\":\"Fiasp\""));
    assert(has(meta, "Quote\\\"\\\\\\u000a"));
    run("/v1/iob?at=1700000000", 200);
    assert(iob_at == 1700000000);
    auto before = iob_calls;
    state.d.IOB = false;
    assert(has(run("/v1/iob", 200), "\"status\":\"disabled\",\"value\":null"));
    assert(iob_calls == before);
    state.d.IOB = true;
    state.insulin.assign(4, Insulin::Not);
    assert(has(run("/v1/iob", 200), "\"status\":\"no_insulin_labels\",\"value\":null"));
    state.insulin[0] = static_cast<Insulin>(255);
    assert(has(run("/v1/iob", 200), "invalid_insulin_category"));
    assert(iob_calls == before);
    state.insulin[0] = Insulin::Aspart;

    Numdata a, b;
    a.values = {{100, 2, 0}, {120, 1, 99}, {130, 5, 1}, {150, 7, 3}};
    b.values = {{105, 3, 2}, {110, 4, 1}, {145, 1, 0}};
    numdatas = {&a, &b};
    auto rows = run("/v1/amounts?start=100&end=150&limit=2", 200);
    assert(has(rows, "\"returned\":2,\"truncated\":true"));
    assert(has(rows, "\"label_id\":0") && has(rows, "\"label_id\":2"));
    assert(!has(rows, "\"time\":110"));
    rows = run("/v1/amounts?start=100&end=150&limit=10", 200);
    assert(has(rows, "\"returned\":5,\"truncated\":false"));
    assert(!has(rows, "\"time\":150"));
    assert(!has(rows, "\"label_id\":99"));
    rows = run("/v1/amounts?start=1000&end=1100", 200);
    assert(has(rows, "\"returned\":0,\"truncated\":false"));

    auto tsv = run("/v1/glucose?start=100&end=200&limit=2&unit=mg%2FdL", 200);
    assert(has(tsv, "X-Juggluco-Returned: 2\r\nX-Juggluco-Truncated: true"));
    assert(!has(tsv, "SENSOR\t102"));
    run("/v1/history?start=100&end=200&calibrated=1&pastvalues=1", 200);
    run("/v1/scans", 200);
    const auto calls = export_calls;
    for (auto target : {"/v1/glucose?start=1", "/v1/glucose?start=2&end=1",
         "/v1/glucose?limit=0", "/v1/glucose?limit=20001", "/v1/glucose?limit=2&limit=3",
         "/v1/glucose?start=1&end=4294967296", "/v1/glucose?start=1&end=9999999",
         "/v1/glucose?unit=wrong", "/v1/glucose?pastvalues=1", "/v1/glucose?limit=-1",
         "/v1/glucose?limit=1%0D%0A", "/v1/glucose?limit=1&", "/v1/glucose?limit=%zz",
         "/v1/amounts?calibrated=1", "/v1/metadata?secret=x", "/v1/iob?at=0",
         "/v1/iob?at=4294967295", "GET /v1/metadata HTTP/1.1\r\n\r\n"}) run(target, 400);
    for (auto target : {"/", "/v1/glucose/", "/v1/glucoseDELETE", "/v1/../metadata",
                        "/x/stream", "/api/v1/treatments", "https://somewhere/v1/metadata"}) run(target, 404);
    assert(export_calls == calls);
    settings = nullptr;
    run("/v1/metadata", 503);
    settings = &state;
    sensors = nullptr;
    run("/v1/glucose", 503);
    std::cout << "data dispatcher: PASS\n";
}
