#pragma once
#include <algorithm>
#include <cstdint>
#include <mutex>
#include <span>
#include <string>
#include <vector>

enum class Insulin : uint8_t { Not, Human, Aspart, Lispro, Glulisine, Fiasp, URli, Afrezza };
constexpr unsigned insulinsNR() { return 8; }
struct TestSettings {
    struct Web { int kind{}; float weight{}; };
    struct Data { bool IOB{true}; int unit{1}; Web Nightnums[5]{}; } d;
    std::vector<std::string> labels{"Aspart", "Duplicate", "Duplicate", "Quote\"\\\n"};
    std::vector<Insulin> insulin{Insulin::Aspart, Insulin::Not, Insulin::Fiasp, Insulin::Not};
    Data *data() { return &d; }
    int getlabelcount() const { return int(labels.size()); }
    std::string_view getlabel(int id) const { return labels.at(id); }
    std::string_view getunitlabel() const { return "mmol/L"; }
    Insulin getIOBtype(int id) const { return insulin.at(id); }
};
struct Num { uint32_t time{}; float value{}; uint32_t type{}; };
struct Numdata {
    std::mutex nummutex;
    std::vector<Num> values;
    const Num *begin() const { return values.data(); }
    bool valid(const Num *n) const { return n->time && n->type < 4; }
    int getfirstpos() const { return 7; }
    std::pair<const Num*, const Num*> getInRange(uint32_t start, uint32_t end) const {
        auto less = [](const Num &n, uint32_t t) { return n.time < t; };
        auto a = std::lower_bound(values.begin(), values.end(), start, less);
        auto b = std::lower_bound(a, values.end(), end, less);
        return {values.data() + (a - values.begin()), values.data() + (b - values.begin())};
    }
};
struct Sensoren {};
extern TestSettings *settings;
extern std::vector<Numdata*> numdatas;
extern Sensoren *sensors;
double getiob(uint32_t);
std::span<char> getstream(int, int, uint32_t, uint32_t, bool, int, bool, int, bool, bool);
std::span<char> gethistory(int, int, uint32_t, uint32_t, bool, int, bool, int, bool, bool);
std::span<char> getscans(int, int, uint32_t, uint32_t, bool, int, bool, int, bool, bool);
