// SPDX-License-Identifier: GPL-3.0-or-later
// Local fixture certificate: openssl req -x509 -newkey rsa:2048 -nodes
//   -keyout key.pem -out cert.pem -days 1 -subj /CN=localhost
//   -addext subjectAltName=DNS:localhost
// Run: SSL_CERT_FILE=cert.pem ./native_https_test cert.pem key.pem
#include "native_https.hpp"
#include <openssl/ssl.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <poll.h>
#include <signal.h>
#include <chrono>
#include <cstdlib>
#include <future>
#include <iostream>
#include <stdexcept>
#include <thread>

using namespace std::chrono_literals;
void require(bool condition, const char* text) { if (!condition) throw std::runtime_error(text); }
class Fixture {
    SSL_CTX* context_{};
    int listener_{-1};
    std::thread worker_;
public:
    std::uint16_t port{};
    Fixture(const char* cert, const char* key, bool stall) {
        context_ = SSL_CTX_new(TLS_server_method());
        require(context_, "Server SSL_CTX_new failed");
        require(SSL_CTX_use_certificate_file(context_, cert, SSL_FILETYPE_PEM) == 1 &&
                SSL_CTX_use_PrivateKey_file(context_, key, SSL_FILETYPE_PEM) == 1, "Fixture certificate load failed");
        listener_ = socket(AF_INET, SOCK_STREAM, 0);
        require(listener_ >= 0, "Fixture socket failed");
        sockaddr_in address{}; address.sin_family = AF_INET; address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        require(bind(listener_, reinterpret_cast<sockaddr*>(&address), sizeof(address)) == 0 &&
                listen(listener_, 1) == 0, "Fixture bind failed");
        socklen_t size = sizeof(address);
        require(getsockname(listener_, reinterpret_cast<sockaddr*>(&address), &size) == 0, "Fixture port failed");
        port = ntohs(address.sin_port);
        worker_ = std::thread([this, stall] {
            pollfd listener{listener_, POLLIN, 0};
            if (poll(&listener, 1, 4000) <= 0) return;
            int fd = accept(listener_, nullptr, nullptr);
            if (fd < 0) return;
            timeval timeout{2, 0};
            setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
            setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
            SSL* ssl = SSL_new(context_); SSL_set_fd(ssl, fd);
            if (SSL_accept(ssl) == 1) {
                char input[4096]{};
                int got = SSL_read(ssl, input, sizeof(input));
                if (got > 0) {
                    if (stall) std::this_thread::sleep_for(500ms);
                    else {
                        const char response[] = "HTTP/1.1 200 OK\r\nContent-Length: 4\r\n\r\nTEST";
                        SSL_write(ssl, response, sizeof(response)-1);
                        // A Content-Length response must complete without EOF.
                        std::this_thread::sleep_for(1000ms);
                    }
                }
            }
            SSL_free(ssl); close(fd);
        });
    }
    ~Fixture() {
        if (worker_.joinable()) worker_.join();
        if (listener_ >= 0) close(listener_);
        if (context_) SSL_CTX_free(context_);
    }
};
int main(int argc, char** argv) {
    if (argc != 3) { std::cerr << "Usage: native_https_test cert.pem key.pem\n"; return 2; }
    // Only this fixture process changes SIGPIPE disposition. Production blocks
    // SIGPIPE within the HTTPS worker and restores its previous signal mask.
    signal(SIGPIPE, SIG_IGN);
    try {
        auto http = jgice::native_https();
        std::atomic_bool cancel{false};
        jgice::HttpRequest request{"localhost", 0, "GET", "/description", {0,1,2,0,255}, 3s};
        {
            Fixture fixture(argv[1], argv[2], false); request.port = fixture.port;
            const auto begin = std::chrono::steady_clock::now();
            auto result = http(request, cancel);
            if (result.status != 200) std::cerr << result.error << '\n';
            require(result.status == 200 && result.body == std::vector<std::uint8_t>({'T','E','S','T'}),
                    "Trusted native TLS request failed");
            require(std::chrono::steady_clock::now()-begin < 750ms, "Native HTTPS waited for EOF despite Content-Length");
        }
        {
            Fixture fixture(argv[1], argv[2], false); request.port = fixture.port; request.host = "127.0.0.1";
            auto result = http(request, cancel);
            require(result.status == 0 && result.error.find("IP mismatch") != std::string::npos,
                    "Hostname-only certificate accepted for IP address");
        }
        {
            const char* previous = std::getenv("SSL_CERT_FILE");
            const std::string saved = previous ? previous : "";
            const bool had_value = previous != nullptr;
            setenv("SSL_CERT_FILE", "/nonexistent-jgice-test-certificate-file", 1);
            Fixture fixture(argv[1], argv[2], false); request.port = fixture.port; request.host = "localhost";
            auto result = http(request, cancel);
            if (had_value) setenv("SSL_CERT_FILE", saved.c_str(), 1); else unsetenv("SSL_CERT_FILE");
            require(result.status == 0 && result.error.find("certificate-chain") != std::string::npos,
                    "Untrusted fixture certificate accepted");
        }
        {
            Fixture fixture(argv[1], argv[2], true); request.port = fixture.port; request.host = "localhost";
            auto future = std::async(std::launch::async, [&] { return http(request, cancel); });
            std::this_thread::sleep_for(100ms); cancel.store(true);
            const auto begin = std::chrono::steady_clock::now();
            auto result = future.get();
            require(result.status == 0 && result.error.find("cancelled") != std::string::npos,
                    "Blocked native TLS read ignored cancellation");
            require(std::chrono::steady_clock::now()-begin < 250ms, "Native TLS cancellation too slow");
        }
        std::cout << "Native HTTPS verified trust+name, untrusted CA and IP mismatch rejection, Content-Length completion, cancellation: PASS\n";
        return 0;
    } catch (const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
