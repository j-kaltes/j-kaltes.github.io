// SPDX-License-Identifier: GPL-3.0-or-later
#include "jgice/protocol.hpp"

#include <atomic>
#include <chrono>
#include <future>
#include <iostream>
#include <map>
#include <memory>
#include <mutex>
#include <stdexcept>
#include <string>
#include <thread>

using namespace std::chrono_literals;
using jgice::Bytes;
using jgice::Channel;
using jgice::Key;

namespace {
void check(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

Key make_key() {
    Key key{};
    jgice::secure_random(key.data(), key.size());
    return key;
}

struct Pair {
    std::unique_ptr<Channel> client;
    std::unique_ptr<Channel> server;
    std::mutex mutex;
    std::vector<Bytes> packets;
    std::map<int, int> drops;
    bool corrupt_data_once = false;
    bool duplicate_data = false;

    explicit Pair(Key key = make_key()) {
        client.reset(new Channel(key, false, [this](const Bytes& b) { forward(false, b); }));
        server.reset(new Channel(key, true, [this](const Bytes& b) { forward(true, b); }));
    }

    void forward(bool from_server, const Bytes& original) {
        Bytes b = original;
        bool duplicate = false;
        {
            std::lock_guard<std::mutex> guard(mutex);
            packets.push_back(b);
            const int kind = b.at(4);
            if (drops[kind] > 0) { --drops[kind]; return; }
            if (kind == 5 && corrupt_data_once) {
                b.back() ^= 0x40;
                corrupt_data_once = false;
            }
            duplicate = kind == 5 && duplicate_data;
        }
        auto& peer = from_server ? client : server;
        peer->on_datagram(b.data(), b.size());
        if (duplicate) peer->on_datagram(b.data(), b.size());
    }

    void connect() {
        check(client->connect(5s), "Client handshake failed");
        check(server->connect(100ms), "Server handshake failed");
        check(client->established() && server->established(), "Handshake did not establish both peers");
    }

    void unique_nonces() {
        // A retransmission may repeat a nonce only with the exact same packet.
        // Each kind/direction/session has its own derived key. Handshake kinds
        // use their 128-bit peer identifier, DATA/ACK use sequence64.
        std::map<std::string, Bytes> seen;
        for (const auto& p : packets) {
            std::string identity;
            identity.push_back(char(p[4]));
            identity.push_back(char(p[5]));
            identity.append(reinterpret_cast<const char*>(p.data() + 8), 32);
            if (p[4] >= 5) identity.append(reinterpret_cast<const char*>(p.data() + 40), 8);
            auto result = seen.emplace(identity, p);
            check(result.second || result.first->second == p,
                  "Nonce reused for different authenticated content");
        }
    }
};

Bytes pattern(std::size_t size) {
    Bytes bytes(size);
    for (std::size_t i = 0; i < size; ++i) bytes[i] = static_cast<std::uint8_t>(i * 37 + i / 251);
    return bytes;
}

void test_records() {
    Pair p;
    p.connect();
    for (auto size : {std::size_t(0), std::size_t(1), std::size_t(1024), std::size_t(1025), std::size_t(100003)}) {
        const auto data = pattern(size);
        check(p.client->send_message(data), "Sending request failed");
        Bytes received;
        check(p.server->receive_message(received, 100ms) && received == data, "Request contents differ");
        check(!p.server->receive_message(received, 1ms), "Request delivered twice");
        check(p.server->send_message(data), "Sending response failed");
        check(p.client->receive_message(received, 100ms) && received == data, "Response contents differ");
    }
    p.unique_nonces();
}

void test_loss_duplicates_and_corruption() {
    Pair p;
    for (int kind = 1; kind <= 4; ++kind) p.drops[kind] = 1;
    p.connect();
    p.drops[5] = 1;
    p.drops[6] = 1;
    p.corrupt_data_once = true;
    p.duplicate_data = true;
    const auto data = pattern(4500);
    check(p.client->send_message(data, 5s), "Lost/corrupted request did not recover");
    Bytes received;
    check(p.server->receive_message(received, 100ms) && received == data, "Recovered contents differ");
    check(!p.server->receive_message(received, 5ms), "Duplicate request delivered to application");
    p.unique_nonces();
}

void test_wrong_key_and_wire_validation() {
    const auto key = make_key();
    auto wrong = key;
    wrong[0] ^= 1;
    std::unique_ptr<Channel> client;
    Channel server(key, true, [&](const Bytes& b) { client->on_datagram(b.data(), b.size()); });
    client.reset(new Channel(wrong, false, [&](const Bytes& b) { server.on_datagram(b.data(), b.size()); }));
    check(!client->connect(40ms), "Wrong key established a connection");
    check(!server.established(), "Server accepted wrong key");
    Bytes garbage(Channel::max_datagram_size + 1, 0xff);
    for (std::size_t size = 0; size < 80; ++size) server.on_datagram(garbage.data(), size);
    server.on_datagram(garbage.data(), garbage.size());
    server.on_datagram(nullptr, 100);
    check(!server.established(), "Malformed wire data established a connection");
}

void test_previous_session_replay() {
    const auto key = make_key();
    Pair first(key);
    first.connect();
    check(first.client->send_message(pattern(2300)), "Initial replay-test send failed");
    Bytes received;
    check(first.server->receive_message(received, 10ms), "Initial replay-test receive failed");

    Pair fresh(key);
    fresh.connect();
    for (const auto& p : first.packets) {
        auto& peer = p[5] ? fresh.client : fresh.server;
        peer->on_datagram(p.data(), p.size());
    }
    check(!fresh.server->receive_message(received, 5ms), "Old request replayed into fresh session");
    check(!fresh.client->receive_message(received, 5ms), "Old response replayed into fresh session");
    check(fresh.client->send_message(pattern(7)), "Replay disturbed current session");
    check(fresh.server->receive_message(received, 20ms) && received == pattern(7),
          "Current session failed after old transcript replay");

    std::vector<Bytes> challenges;
    Channel restarted(key, true, [&](const Bytes& b) { challenges.push_back(b); });
    // Replaying an entire previously valid transcript against a restarted
    // server must not authenticate: its challenge includes fresh server random.
    for (const auto& p : first.packets) if (!p[5]) restarted.on_datagram(p.data(), p.size());
    check(!restarted.established(), "Old full transcript authenticated restarted server");
    check(!restarted.receive_message(received, 5ms), "Restarted server delivered old request");
    check(!challenges.empty() && challenges.front()[4] == 2, "Replayed hello did not produce fresh challenge");
}

void test_authenticated_tampering() {
    Pair p;
    p.connect();
    check(p.client->send_message(pattern(20)), "Initial tamper-test send failed");
    Bytes received;
    check(p.server->receive_message(received, 10ms), "Initial tamper-test receive failed");
    Bytes packet;
    for (const auto& b : p.packets) if (b[4] == 5 && !b[5]) { packet = b; break; }
    check(!packet.empty(), "Missing recorded packet");
    for (std::size_t i = 0; i < packet.size(); ++i) {
        auto changed = packet;
        changed[i] ^= 1;
        p.server->on_datagram(changed.data(), changed.size());
    }
    check(!p.server->receive_message(received, 5ms), "Tampered packet delivered");
    check(p.client->send_message(pattern(23)), "Tampering disrupted valid session");
    check(p.server->receive_message(received, 10ms) && received == pattern(23), "Post-tamper data wrong");
}

void test_backpressure_and_close() {
    Pair p;
    p.connect();
    check(p.client->send_message(pattern(6)), "Initial backpressure send failed");
    auto send = std::async(std::launch::async, [&] { return p.client->send_message(pattern(8), 3s); });
    check(send.wait_for(20ms) == std::future_status::timeout, "Unread record was overwritten");
    Bytes received;
    check(p.server->receive_message(received, 20ms) && received == pattern(6), "First queued record wrong");
    check(send.get(), "Backpressure did not recover after receiver consumed record");
    check(p.server->receive_message(received, 20ms) && received == pattern(8), "Second queued record wrong");

    auto waiter = std::async(std::launch::async, [&] { Bytes b; return p.server->receive_message(b, 30s); });
    p.server->close();
    check(waiter.wait_for(100ms) == std::future_status::ready && !waiter.get(), "close did not release receiver");
}

void test_size_limit_and_timeout() {
    Pair p;
    p.connect();
    check(!p.client->send_message(Bytes(Channel::max_message_size + 1), 100ms), "Oversized message allowed");
    check(!p.client->established(), "Size-limit failure left session usable");

    Pair q;
    q.connect();
    q.drops[6] = 100;
    check(!q.client->send_message(pattern(7), 40ms), "Missing ACK did not time out");
    check(!q.client->established(), "Timeout left partially sent session usable");
}
} // namespace

int main() {
    try {
        test_records();
        test_loss_duplicates_and_corruption();
        test_wrong_key_and_wire_validation();
        test_previous_session_replay();
        test_authenticated_tampering();
        test_backpressure_and_close();
        test_size_limit_and_timeout();
        std::cout << "protocol_test: PASS (records, loss, duplicates, tampering, replay, bounds, backpressure, close)\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "protocol_test: FAIL: " << e.what() << '\n';
        return 1;
    }
}
