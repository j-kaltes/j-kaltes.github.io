#include "jgice/ice.hpp"
#include "jgice/protocol.hpp"
#include <algorithm>
#include <chrono>
#include <condition_variable>
#include <cstring>
#include <deque>
#include <future>
#include <iostream>
#include <mutex>
#include <stdexcept>
#include <thread>

using namespace std::chrono_literals;
namespace {
void require(bool value, const char* message) {
    if (!value) throw std::runtime_error(message);
}
std::uint32_t read32(const std::uint8_t* p) {
    return p[0] | (std::uint32_t(p[1]) << 8) | (std::uint32_t(p[2]) << 16) | (std::uint32_t(p[3]) << 24);
}
std::vector<std::uint8_t> back(std::string_view text) {
    std::vector<std::uint8_t> result{0x78, 0x56, 0x34, 0x12};
    result.insert(result.end(), text.begin(), text.end());
    result.push_back(0);
    return result;
}
struct Rendezvous {
    std::mutex mutex;
    std::condition_variable changed;
    std::string descriptions[2];
    std::deque<std::string> candidates[2];
    bool done[2]{};
    jgice::HttpResponse request(const jgice::HttpRequest& req, const std::atomic_bool& cancel) {
        require(req.host == "test.invalid" && req.port == 6789, "Signalling host changed");
        require(req.body.size() >= 14, "Short Agent_data request");
        const auto labels = read32(req.body.data()), length = read32(req.body.data() + 4);
        const auto side = unsigned(req.body[8] - '0');
        require(side < 2 && req.body.size() == 14 + labels + length, "Agent_data length mismatch");
        require(req.body[9 + labels] == 0 && req.body[10 + labels + length] == 0,
                "Agent_data missing string terminator");
        const std::string description(reinterpret_cast<const char*>(req.body.data() + 10 + labels), length);
        std::unique_lock lock(mutex);
        const auto until = std::chrono::steady_clock::now() + req.timeout;
        auto wait = [&](auto predicate) {
            while (!predicate() && !cancel.load() && std::chrono::steady_clock::now() < until)
                changed.wait_for(lock, 20ms);
            return predicate() && !cancel.load();
        };
        if (req.path == "/description") {
            if (req.method == "PUT") { descriptions[side] = description; changed.notify_all(); }
            if (!wait([&] { return !descriptions[1-side].empty(); })) return {};
            return {200, back(descriptions[1-side]), {}};
        }
        if (req.path == "/address") {
            if (req.method == "PUT") {
                candidates[side].push_back(description); changed.notify_all(); return {200, {}, {}};
            }
            if (!wait([&] { return !candidates[1-side].empty() || done[1-side]; })) return {};
            if (candidates[1-side].empty()) return {200, back(""), {}};
            auto text = std::move(candidates[1-side].front()); candidates[1-side].pop_front();
            return {200, back(text), {}};
        }
        if (req.path == "/done" && req.method == "PUT") {
            require(description == descriptions[side], "/done must contain initial SDP");
            done[side] = true; changed.notify_all(); return {200, {}, {}};
        }
        return {400, {}, "Unknown path"};
    }
};
}

int main() {
    try {
        const auto encoded = jgice::encode_agent_data(1, "abcdefghijklmnop", "v=0");
        require(encoded.size() == 33, "sizeof(Agent_data) wire padding mismatch");
        require(read32(encoded.data()) == 16 && read32(encoded.data()+4) == 3 && encoded[8] == '1',
                "Agent_data scalar layout mismatch");
        require(std::memcmp(encoded.data()+9, "abcdefghijklmnop\0v=0\0\0\0\0", 24) == 0,
                "Agent_data label/SDP offsets mismatch");
        auto decoded = jgice::decode_back_description(back("candidate:abc"));
        require(decoded && decoded->was == 0x12345678 && decoded->description == "candidate:abc",
                "BackDescription codec mismatch");
        require(!jgice::decode_back_description(std::vector<std::uint8_t>{0, 1, 2}), "Truncated header accepted");
        bool invalid = false;
        try { jgice::encode_agent_data(2, "abcdefghijk", ""); } catch (const std::invalid_argument&) { invalid = true; }
        require(invalid, "Invalid side accepted");

        Rendezvous server;
        auto http = [&server](const auto& request, const auto& stop) { return server.request(request, stop); };
        jgice::IceConfig config;
        config.signal_host = "test.invalid";
        config.label = "0123456789abcdef0123456789abcdef";
        config.connect_timeout = 15s;
        config.http_timeout = 1s;
        config.bind_address = "127.0.0.1";
        config.side = 0;
        jgice::IcePeer phone(config, http);
        config.side = 1;
        jgice::IcePeer client(config, http);
        jgice::Key key{};
        jgice::secure_random(key.data(), key.size());
        jgice::Channel phone_channel(key, true, [&](const auto& data) { phone.send_datagram(data); });
        jgice::Channel client_channel(key, false, [&](const auto& data) { client.send_datagram(data); });
        struct CloseBeforeChannels {
            jgice::IcePeer &phone, &client;
            ~CloseBeforeChannels() { phone.close(); client.close(); }
        } cleanup{phone, client};
        phone.set_receive_handler([&](const auto* data, auto size) {
            phone_channel.on_datagram(data, size);
        });
        client.set_receive_handler([&](const auto* data, auto size) {
            client_channel.on_datagram(data, size);
        });
        auto phone_connect = std::async(std::launch::async, [&] { return phone.connect(); });
        auto client_connect = std::async(std::launch::async, [&] { return client.connect(); });
        const bool a = phone_connect.get(), b = client_connect.get();
        if (!a || !b) throw std::runtime_error("Loopback ICE failed: " + phone.error() + "; " + client.error());
        {
            std::lock_guard lock(server.mutex);
            require(!server.done[0] && !server.done[1], "/done sent before application_ready");
        }
        require(client_channel.connect(3s) && phone_channel.connect(3s), "Encrypted Channel handshake over ICE failed");
        jgice::Bytes request(16387), reply(4109), request_received, reply_received;
        for (std::size_t i = 0; i < request.size(); ++i) request[i] = static_cast<std::uint8_t>(i * 11);
        for (std::size_t i = 0; i < reply.size(); ++i) reply[i] = static_cast<std::uint8_t>(i * 7);
        require(client_channel.send_message(request, 5s) && phone_channel.receive_message(request_received, 1s),
                "Encrypted fragmented request over ICE failed");
        require(phone_channel.send_message(reply, 5s) && client_channel.receive_message(reply_received, 1s),
                "Encrypted fragmented response over ICE failed");
        require(request_received == request && reply_received == reply, "Encrypted ICE message data mismatch");
        phone.application_ready(); client.application_ready();
        {
            std::unique_lock lock(server.mutex);
            require(server.changed.wait_for(lock, 3s, [&] { return server.done[0] && server.done[1]; }),
                    "/done not sent after application_ready");
        }
        phone.close(); client.close();

        // Cancel while side 1 is still waiting for a peer description.
        Rendezvous absent_server;
        jgice::IcePeer absent(config, [&](const auto& req, const auto& stop) { return absent_server.request(req, stop); });
        auto pending = std::async(std::launch::async, [&] { return absent.connect(); });
        std::this_thread::sleep_for(100ms);
        const auto cancelled_at = std::chrono::steady_clock::now();
        absent.close();
        require(!pending.get(), "Cancelled connection succeeded");
        require(std::chrono::steady_clock::now() - cancelled_at < 2s, "Cancellation exceeded bounded shutdown");
        std::cout << "Signalling codec, direct ICE + encrypted fragmented Channel exchange, /done ordering, cancellation: PASS\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << e.what() << '\n';
        return 1;
    }
}
