#pragma once
#include <vector>
#include <stdio.h>
template <typename T>
class logvector:public std::vector<T> {

    public:
    ~logvector() {
        LOGGER("~logvector() %p\n",this); 
        }
    };

