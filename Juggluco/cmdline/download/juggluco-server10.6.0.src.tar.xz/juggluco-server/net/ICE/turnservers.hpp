/*      This file is part of Juggluco, an Android app to receive and display         */
/*      glucose values from Freestyle Libre 2, Libre 3, Dexcom G7/ONE+,              */
/*      Sibionics GS1Sb and Accu-Chek SmartGuide sensors.                            */
/*                                                                                   */
/*      Copyright (C) 2021 Jaap Korthals Altes <jaapkorthalsaltes@gmail.com>         */
/*                                                                                   */
/*      Juggluco is free software: you can redistribute it and/or modify             */
/*      it under the terms of the GNU General Public License as published            */
/*      by the Free Software Foundation, either version 3 of the License, or         */
/*      (at your option) any later version.                                          */
/*                                                                                   */
/*      Juggluco is distributed in the hope that it will be useful, but              */
/*      WITHOUT ANY WARRANTY; without even the implied warranty of                   */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                         */
/*      See the GNU General Public License for more details.                         */
/*                                                                                   */
/*      You should have received a copy of the GNU General Public License            */
/*      along with Juggluco. If not, see <https://www.gnu.org/licenses/>.            */
/*                                                                                   */
/*      Fri Nov 21 11:08:14 CET 2025                                                 */
        {
        .host="relay1.expressturn.com",
        .username="000000002079170997",
        .password="vDWH/Pk0bOyZ1xkwvHCGT+ldPX4=",
        .port=3480
        },
        {
        .host="standard.relay.metered.ca",
        .username= "7dff0fcafd74f137f653c860",
        .password= "aKI7B12zpAOCl043",
        .port=80
        },
        {
        .host="global.turn.twilio.com",
        .port=3478
        },
/*        {
        .host="relay1.expressturn.com",
        .username="efPU52K4SLOQ34W2QY",
        .password="1TJPNFxHKXrZfelz",
        .port=3480
        }, */
        {
        .host="fr-turn2.xirsys.com",
        .username="slx-nGB8vwrpSreWi0o0GAxRyxAo5LIfe_kO5HZAlX5MYvMRvmQZQ4pIQFm1ycNhAAAAAGk69AJqa2FsdGVz",
        .password="1db769d4-d6b0-11f0-9a74-7ea7fee00527",
        .port=80
        },
        {
        .host="standard.relay.metered.ca",
        .username= "7dff0fcafd74f137f653c860",
        .password= "aKI7B12zpAOCl043",
        .port=443
        },
        {
        .host="fr-turn2.xirsys.com",
        .username="slx-nGB8vwrpSreWi0o0GAxRyxAo5LIfe_kO5HZAlX5MYvMRvmQZQ4pIQFm1ycNhAAAAAGk69AJqa2FsdGVz",
        .password="1db769d4-d6b0-11f0-9a74-7ea7fee00527",
        .port=3478
        },
        {
        .host="a.juggluco.nl",
        .username="juggluco",
        .password="UilM7%Vlomp8", 
        .port=3478
        }

      /* 
        {
         .host="openrelay.metered.ca",
         .username="openrelayproject",
         .password="openrelayproject",
         .port=80
         },
        {
         .host="openrelay.metered.ca",
         .username="openrelayproject",
         .password="openrelayproject",
         .port=443
         } */
