#include "jugglucotext.hpp"
#ifdef INJUGGLUCO
#ifndef WEAROS
constexpr static std::string_view uklabels[]={"Вугл.","Дек.","Швидк.","Довг.","Велос","Прог.","Кров"};
constexpr static Shortcut_t  ukshortinit[]= { {"Bread",
        .48},
        {"Currantbun1",
        .56f},
        {"Currantbun2",
        .595f},
        {"Grapes",
        .165f},
        {"FruitYog",
        .058f},
        {"Rice",
        .75f},
        {"Macaroni",
        .65f},
        {"Tomato",
        .03f},
        {"Mexican mix",
        .078f},
        {"OrangeJuice",
        .109f},
        {"SportPowder",
        .873f},
        {"Mix(Carrot)",
        .07f},
        {"Mix mushro",
        .07300000f}};
#endif
#endif //INJUGGLUCO

jugglucotext uktext {
.daylabel={"Ндл","Пнд","Втр","Срд","Чтв","Птн","Сбт"},

#ifdef INJUGGLUCO
.speakdaylabel={
"неділя",
"понеділок",
"вівторок",
"середа",
"четвер",
"п'ятниця",
"субота"
},
.monthlabel={"Сiч","Лют","Бер","Квi","Тра","Чер","Лип","Сер","Вер","Жов","Лис","Гру"},
.scanned="Відскановано",
.readysecEnable="Датчик готовий через %d хвилин. Скануйте знову, щоб увімкнути потокове передавання.",
.readysec="Датчик готовий через %d хвилин.",
.networkproblem="Немає глюкози від дзеркала",
.enablebluetooth="Увімкніть Bluetooth",
.useBluetoothOff="'Використовуйте Bluetooth' вимк",
.noconnectionerror=": Немає з'єднання",
.stsensorerror=": Помилка датчика",
.streplacesensor=": Замінити датчик?",
.endedformat="%s припинив працювати. state=%d",
.notreadyformat="%s не готовий. state=%d",
#ifndef WEAROS
	.median="Медіана",
	.middle="Середній",
#endif
	.history="Історія",
//	.historyinfo="Раз у 15 хвилин.\nЗапам'ятовується на датчику 8 годин.\nСканування передає їх до цієї програми.\nДатчик: ",
//	.history3info="Раз у 5 хвилин.\nЗапам'ятовується на датчику 14 днів.\nПередано через Bluetooth до цієї програми.\nДатчик: ",
	.sensorstarted= "Датчик запущений:",
	.lastscanned="Останнє сканування:",
	.laststream="Останній потік:",
	.sensorends="Датчик закінчується: ",
	.sensorexpectedend="Очікується закінчення: ",
#endif //INJUGGLUCO
#ifndef WEAROS
#ifdef INJUGGLUCO
	.newamount="Нова сума",
	.averageglucose="Середня глюкоза: ",
	.duration="Тривалість: %.1f днів",
	.timeactive="%.1f%% активного часу",
	.nrmeasurement="Кількість вимірювань: %d",
	.EstimatedA1C="uGMI ≈ Оцінно A1C: %.1f%% (%d mmol/mol)",
	.GMI="Індикатор контролю рівня глюкози (GMI): %.1f%% (%d mmol/mol)",
	.SD="SD: %.2f",
	.glucose_variability="Варіабельність глюкози: %.1f%%",
     .menustr0={
		"ChatGPT",
		"Меню",
		"Дивитися",
		"Датчик",
		"Налашт.",
#if defined(SIBIONICS)
"Фото",
#else
		"Аб Juggluco",
#endif
		"Закрити",
		"Стоп тривоги"
		},
	.menustr1={
		"Експорт",
		"Клон",
		uktext.newamount,
		"Список",
#else
       .statistics=
#endif //INJUGGLUCO
		"Статистика",
#ifdef INJUGGLUCO
		"Говорити",
		"Плавати"
		},

	.menustr2= {"System UI",
	    "Скани",
	    "Потік",
	    "Історія",
	    "Суми",
	    "Їжа",
	"Dark mode"},
	.menustr3= {hourminstr,"Пошук","Дата","День назад","Через день","Тиждень тому","Тиждень пізн"},
#endif //INJUGGLUCO
#else
 .amount="Сума",
 .menustr0= {
	"Клон",
	"Датчик",
	"Дисплей",
        "Налашт.",
	"Стоп тривоги" },
.menustr2= {"Дата",hourminstr,
"День назад",uktext.amount},
#endif

#ifdef INJUGGLUCO
	.scanerrors={
		{"Помилка сканування (%d)","Спробуйте знову"},
		{"Помилка встановлення","?"},
		{"Помилка обробки даних","Спробуйте знову"},
		{"Активація датчика",""},
		{"Датчик точно закінчився",""},

		{"Датчик буде готовий через","%d хвилин"},
		{"Помилка датчика (373)","Спробуйте ще раз пізніше"},
		{"Новий датчик активовано","Відскануйте ще раз, щоб використати його"},
		{"","Блокує дотик під час сканування"},
		{"",""},
		{"Помилка ініціалізації бібліотеки","Чи відсутні спільні бібліотеки?"},
		{"Помилка ініціалізації класу","Робити щось"},
		{"Процедура триває надто довго","Я вбиваю програму"},
		{"Замініть датчик (365)","Ваш датчик не працює. Видаліть датчик і запустіть новий."},
		{"Замініть датчик (368)","Ваш датчик не працює. Видаліть датчик і запустіть новий."},
		{"",""},
		{"Помилка сканування","Спробуйте знову"}},

.libre3scanerror={"FreeStyle Libre 3, Помилка сканування", "Спробуйте знову"},
.libre3wrongID={"Помилка: неправильний ідентифікатор облікового запису?",
	R"(Він має збігатися з ідентифікатором, використаним під час активації датчика. Щоб отримати його з LibreView, відкрийте Ліве меню->Налаштування->Обмін даними->LibreView->"Отримати ідентифікатор облікового запису")"},
.libre3scansuccess= {"FreeStyle Libre 3 датчик", "Тепер Juggluco отримуватиме значення глюкози"},
.unknownNFC={"Нерозпізнана помилка сканування NFC", "Спробуйте знову"},
.nolibre3={"Датчик FreeStyle Libre 3",
	"Завантажте правильну версію з https://www.juggluco.nl/download.html"},
.libre3zeroID={"Помилка: нульовий ідентифікатор облікового запису?",
	R"(Відкрийте Ліве меню->Налаштування->Обмін даними->Libreview->"Отримати ідентифікатор облікового запису", щоб установити ненульовий ідентифікатор.)"},
.needsandroid8="Потрібен щонайменше Android 8"sv,
#ifndef WEAROS
	.advancedstart= R"(<h1>Модифікований пристрій</h1>
<p>Одна з бібліотек, які використовуються цією програмою,
має ПОМИЛКУ, яка призводить до збою, якщо вона виявляє певні файли.
Ваш пристрій містить деякі з цих файлів. Ця програма містить хак для
обходу цієї ПОМИЛКИ, але, ймовірно, краще зробити ці файли такими, що
їх неможливо виявити, іншим способом. Magisk, наприклад, має можливість
приховати root для певних програм (Magiskhide або Denylist) і змінити
власну назву, обидва необхідні. У вашому випадку є проблеми з наступним файлом)",
	.add_s=true,
.shortinit=ukshortinit,
.labels=uklabels,
#endif
#ifndef DONTTALK
.checked="перевірено",
.unchecked="не перевірено",
.Undetermined="",
.FallingQuickly="Швидко падає",
.Falling="Падіння",
.Stable="Змінюється повільно",
.Rising="Підйом",
.RisingQuickly="Швидко піднімається",
#endif
.receivingpastvalues="Отримання старих значень",
.receivingdata="Отримання даних",
.unsupportedSibionics="Непідтримуваний датчик Sibionics"sv,
.waitingforconnection="Очікування з’єднання"sv,
.deleted="Видалено"sv,
.nolocationpermission="Потрібен дозвіл на місцезнаходження"sv,
.nonearbydevicespermission="Потрібен дозвіл «Пристрої поблизу»"sv
#endif //INJUGGLUCO
,.summarygraph="Зведений графік"sv
,.logdays="Щоденний журнал"sv
,.unhide="Показати"sv

		}


		;

addlang(uk);
