#ifndef JUICE_JUGGLUCO_H
#define JUICE_JUGGLUCO_H

#include "juice.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Extra space for suffixes such as " Server Reflexive".
 */
#define JUICE_MAX_TYPED_ADDRESS_STRING_LEN (JUICE_MAX_ADDRESS_STRING_LEN + 32)

/*
 * Juggluco extension: reset the current ICE session while retaining the same
 * juice_agent_t object and its copied configuration/callbacks.
 */
JUICE_EXPORT void resetAgent(juice_agent_t *agent);

/*
 * Juggluco extension: selected local/remote addresses with the ICE candidate
 * type appended to the textual address.
 */
JUICE_EXPORT int juice_get_selected_addresses_inc_type(
    juice_agent_t *agent,
    char *local, size_t local_size,
    char *remote, size_t remote_size);

#ifdef __cplusplus
}
#endif

#endif
