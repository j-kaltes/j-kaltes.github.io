#pragma once
#include <cstdint>
#include <span>

namespace abbott_recovered {
inline constexpr unsigned minutes_per_day = 24 * 60;
inline constexpr std::uint16_t libre_wear_minutes = 14 * minutes_per_day;
inline constexpr std::uint16_t libre_plus_wear_minutes = 15 * minutes_per_day;

// These are the generation ranges Juggluco uses to select its NFC and BLE
// exchanges. The region and manufacturer bytes may vary within a generation.
inline constexpr int libre_security_generation(std::uint8_t type) {
    switch (type >> 4) {
        case 3: return (type & 15) < 9 ? 1 : 2;
        case 7: return (type & 15) < 4 ? 1 : 2;
        default: return 0;
    }
}

inline constexpr bool encrypted_scan_only(std::uint8_t type) {
    return type >= 3 && type <= 15;
}

inline constexpr bool classic_payload_cipher(std::uint8_t type) {
    return (type >= 0x30 && type <= 0x38) || (type >= 0x70 && type <= 0x78);
}

inline constexpr std::uint16_t nominal_wear_minutes(std::uint8_t type) {
    switch (type) {
        case 4: case 0x31: case 0x36: case 0x3a: case 0x71: case 0x7a:
            return libre_plus_wear_minutes;
        case 6: case 0x32: case 0x37: case 0x3b: case 0x72: case 0x7b:
            return 21 * minutes_per_day;
        case 0x33:
            return 30 * minutes_per_day;
        case 5: case 0x34: case 0x38: case 0x3c: case 0x74: case 0x7c:
            return 10 * minutes_per_day;
        default:
            return libre_wear_minutes;
    }
}

struct PatchMetadata {
    unsigned family;
    std::uint8_t activation_command;
    unsigned warmup_minutes, wear_minutes;
};

inline constexpr PatchMetadata patch_metadata(std::span<const std::uint8_t, 6> info) {
    const auto type = info[2];
    const unsigned family = type >> 4;
    const bool signed_activation = encrypted_scan_only(type) || classic_payload_cipher(type);
    return {(family == 3 || family == 7) ? family : 0,
            std::uint8_t(signed_activation ? 0xa1 : 0xa0), 60, nominal_wear_minutes(type)};
}
} // namespace abbott_recovered
